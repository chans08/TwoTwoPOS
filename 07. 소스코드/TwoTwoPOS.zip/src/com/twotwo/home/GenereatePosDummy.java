package com.twotwo.home;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

public class GenereatePosDummy {

	public static void main(String[] args) {

		// #01. 영업일자(날짜와 날씨 데이터)
		//operateDate();
		
		// #02. 재고내역
		//inventory();
		
		// #03. 결제내역
		//payment();

	}// method: main

//=====================================================================================================================

	private static void operateDate() {

		String[] weatherSnow = { "sunny", "cloudy", "snowy" };
		String[] weatherRain = { "sunny", "cloudy", "rainy" };

		String sql = "INSERT INTO tblOperateDate (operateDate, weatherName, temperature) " + "VALUES (?, ?, ?)";

		try {

			DBUtil util = new DBUtil();
			Connection conn = util.connect();
			PreparedStatement stat = conn.prepareStatement(sql);

			Random rnd = new Random();
			Calendar c = Calendar.getInstance();

			c.set(Calendar.MONTH, c.get(Calendar.MONTH) + 1);
			c.set(Calendar.DATE, -941);

			for (int i = 0; i < 941; i++) {

				// operatePoint
				stat.setString(1, String.format("%tF", c));
				c.add(Calendar.DATE, 1);
				int month = c.get(Calendar.MONTH) + 1;

		// -----------------------------------------------------------------------------------------

				// weatherName, temperature
				if (month == 1 || month == 2 || month == 11 || month == 12) { // 겨울

					double rndTemperature = Math.random();
					int temperature = (int) (rndTemperature * 5) - 20;
					stat.setString(2, weatherSnow[rnd.nextInt(weatherSnow.length)]); // 날씨
					stat.setInt(3, temperature); // 온도

				} else if (month == 3 || month == 4) { // 봄

					double rndTemperature = Math.random();
					int temperature = (int) (rndTemperature * 15) - 5;
					stat.setString(2, weatherRain[rnd.nextInt(weatherRain.length)]);
					stat.setInt(3, temperature);

				} else if (month == 5 || month == 6 || month == 7 || month == 8) { // 여름

					double rndTemperature = Math.random();
					int temperature = (int) (rndTemperature * 35) + 15;
					stat.setString(2, weatherRain[rnd.nextInt(weatherRain.length)]);
					stat.setInt(3, temperature);

				} else if (month == 9 || month == 10) { // 가을

					double rndTemperature = Math.random();
					int temperature = (int) (rndTemperature * 20) + 5;
					stat.setString(2, weatherRain[rnd.nextInt(weatherRain.length)]);
					stat.setInt(3, temperature);

				}

				stat.executeUpdate();

			}

			System.out.println("operatePoint Inserted.");

		} catch (Exception e) {
			System.out.println("GenerateDummy.main : " + e.toString());
		}

	}// method: operateDate

//=====================================================================================================================

	private static void payment() {

		String sql = "INSERT INTO tblPayment (paymentSeq, orderNumber, orderAmount, entirePayAmount, payAmount, discountAmount, "
				+ "card, cash, refund, takeout, memberSeq, cardCompanySeq, branchSeq, itemSeq, operateDate) "
				+ "VALUES(paymentSeq.NEXTVAL, " + "?, " // orderNumber(1)
				+ "?, " // orderAmount(2)
				+ "?, " // entirePayAmount(3)
				+ "?, " // payAmount(4)
				+ "?, " // discountAmount(5)
				+ "?, " // card(6)
				+ "?, " // cash(7)
				+ "?, " // refund(8)
				+ "?, " // takeout(9)
				+ "?, " // memberSeq(10)
				+ "?, " // cardCompanySeq(11)
				+ "?, " // branchSeq(12)
				+ "?, " // itemSeq(13)
				+ "?)"; // operateDate(14)

		try {

			DBUtil util = new DBUtil();
			Connection conn = util.connect();
			PreparedStatement stat = conn.prepareStatement(sql);

			Calendar c = Calendar.getInstance();
			c.set(Calendar.MONTH, c.get(Calendar.MONTH) + 1);
			c.set(Calendar.DATE, -941);

			for (int i = 1; i <= 941; i++) {

				// 하루하루의 주문번호(1부터 시작)
				int orderNumber = 1;

				// 하루하루의 고객수(30명 ~ 60명)
				double randomCustomer = Math.random();
				int customerAmount = (int) (randomCustomer * 30) + 30;

				for (int j = 0; j < customerAmount; j++) {

					Random rnd = new Random();
					double randonNum = Math.random();

					// orderNumber(주문번호)
					stat.setInt(1, orderNumber);

					int moreOrder = rnd.nextInt(2);
					if (moreOrder == 1) {
						orderNumber++;
					}

			// -------------------------------------------------------

					// orderAmount(판매개수)
					int orderAmount = (int) (randonNum * 4) + 1;
					stat.setInt(2, orderAmount);

			// -------------------------------------------------------

					// entirePayAmount(전체금액)
					int itemSeq = (int) (randonNum * 50) + 1;
					int itemPrice = 0;

					if (itemSeq == 1) {
						itemPrice = 2500;
					} else if (itemSeq == 2) {
						itemPrice = 3000;
					} else if (itemSeq == 3) {
						itemPrice = 3500;
					} else if (itemSeq == 4) {
						itemPrice = 3500;
					} else if (itemSeq == 5) {
						itemPrice = 4000;
					} else if (itemSeq == 6) {
						itemPrice = 4000;
					} else if (itemSeq == 7) {
						itemPrice = 4000;
					} else if (itemSeq == 8) {
						itemPrice = 4000;
					} else if (itemSeq == 9) {
						itemPrice = 4000;
					} else if (itemSeq == 10) {
						itemPrice = 3800;
					} else if (itemSeq == 11) {
						itemPrice = 3800;
					} else if (itemSeq == 12) {
						itemPrice = 3800;
					} else if (itemSeq == 13) {
						itemPrice = 3800;
					} else if (itemSeq == 14) {
						itemPrice = 3800;
					} else if (itemSeq == 15) {
						itemPrice = 3500;
					} else if (itemSeq == 16) {
						itemPrice = 3500;
					} else if (itemSeq == 17) {
						itemPrice = 3500;
					} else if (itemSeq == 18) {
						itemPrice = 3500;
					} else if (itemSeq == 19) {
						itemPrice = 3500;
					} else if (itemSeq == 20) {
						itemPrice = 3500;
					} else if (itemSeq == 21) {
						itemPrice = 3500;
					} else if (itemSeq == 22) {
						itemPrice = 3500;
					} else if (itemSeq == 23) {
						itemPrice = 3500;
					} else if (itemSeq == 24) {
						itemPrice = 3000;
					} else if (itemSeq == 25) {
						itemPrice = 4500;
					} else if (itemSeq == 26) {
						itemPrice = 4500;
					} else if (itemSeq == 27) {
						itemPrice = 4500;
					} else if (itemSeq == 28) {
						itemPrice = 4500;
					} else if (itemSeq == 29) {
						itemPrice = 3500;
					} else if (itemSeq == 30) {
						itemPrice = 3500;
					} else if (itemSeq == 31) {
						itemPrice = 3500;
					} else if (itemSeq == 32) {
						itemPrice = 4000;
					} else if (itemSeq == 33) {
						itemPrice = 4000;
					} else if (itemSeq == 34) {
						itemPrice = 4000;
					} else if (itemSeq == 35) {
						itemPrice = 4000;
					} else if (itemSeq == 36) {
						itemPrice = 4500;
					} else if (itemSeq == 37) {
						itemPrice = 4500;
					} else if (itemSeq == 38) {
						itemPrice = 5000;
					} else if (itemSeq == 39) {
						itemPrice = 3000;
					} else if (itemSeq == 40) {
						itemPrice = 1000;
					} else if (itemSeq == 41) {
						itemPrice = 2500;
					} else if (itemSeq == 42) {
						itemPrice = 2500;
					} else if (itemSeq == 43) {
						itemPrice = 5000;
					} else if (itemSeq == 44) {
						itemPrice = 5000;
					} else if (itemSeq == 45) {
						itemPrice = 5000;
					} else if (itemSeq == 46) {
						itemPrice = 5000;
					} else if (itemSeq == 47) {
						itemPrice = 4500;
					} else if (itemSeq == 48) {
						itemPrice = 4500;
					} else if (itemSeq == 49) {
						itemPrice = 4500;
					} else if (itemSeq == 50) {
						itemPrice = 4500;
					}

					int entirePayAmount = orderAmount * itemPrice;

					stat.setInt(3, entirePayAmount);

			// -------------------------------------------------------

					// payAmount(결제금액)
					int payAmount = entirePayAmount;
					stat.setInt(4, payAmount);

			// -------------------------------------------------------

					// discountAmount(할인금액)
					stat.setInt(5, 0);

			// -------------------------------------------------------

					int cardCash = rnd.nextInt(2);

					if (cardCash == 0) { // 카드결제

						// card
						stat.setInt(6, payAmount);
						// cash
						stat.setInt(7, 0);

					} else { // 현금결제

						// card
						stat.setInt(6, 0);
						// cash
						stat.setInt(7, payAmount);

					}

			// -------------------------------------------------------

					// refund
					int refund = rnd.nextInt(4);
					if (refund == 3) {
						stat.setInt(8, 1);
					} else {
						stat.setInt(8, 0);
					}

			// -------------------------------------------------------

					// takeout
					int takeout = rnd.nextInt(2);
					stat.setInt(9, takeout);

			// -------------------------------------------------------

					// memberSeq
					int memberSeq = (int) (randonNum * 305) + 1;
					stat.setInt(10, memberSeq);

			// -------------------------------------------------------

					// cardCompanySeq
					int cardCompanySeq = (int) (randonNum * 9) + 1;
					stat.setInt(11, cardCompanySeq);

			// -------------------------------------------------------

					// branchSeq
					stat.setInt(12, 1);

			// -------------------------------------------------------

					// itemSeq
					stat.setInt(13, itemSeq);

			// -------------------------------------------------------

					// operateDate
					stat.setString(14, String.format("%tF", c));

			// -------------------------------------------------------

					// INSERT 실행
					stat.executeUpdate();

				} // for: j

				c.add(Calendar.DATE, 1);

			} // for: i

			System.out.println("payment Inserted.");

		} catch (Exception e) {
			System.out.println("GeneratePosDummy.main : " + e.toString());
		}

	}// method: payment

//=====================================================================================================================

	private static void inventory() {

		String[] inventoryType = { "001", "002", "003" };

		String[] food = { "원두", "우유", "바닐라파우더", "캬라멜시럽", "캬라멜소스", "초콜렛소스", "헤이즐넛시럽", "민트코초파우더", "초콜렛파우더", "고구마페이스트",
				"블랙핀파우더", "홍차파우더", "그린티파우더", "얼그레이", "잉글리쉬블랙퍼스트", "캐모마일", "페퍼민트", "루이보스", "그린티", "자몽베이스", "유자차",
				"레몬베이스", "요거트파우더", "다크초코칩", "쿠앤크분태", "딸기스무디액", "청포도베이스", "오렌지베이스", "바나나", "토마토", "골드키위주스(병)",
				"케일사과주스(병)", "망고주스(병)", "애플주스(병)" };

		String[] product = { "ICE컵R", "ICE컵L", "HOT컵R", "HOT컵R", "ICE컵뚜껑", "HOT컵뚜껑", "컵홀더", "빨대", "스푼", "포크", "티슈",
				"물티슈", "진동벨", "영수증용지", "물통", "MD상품", "케익포장용기", "트레이", "포장봉투", "키친타올", "접시" };

		String[] etc = { "와플", "크림치즈", "어니언베이글", "플레인베이글", "치즈케익", "프렌치초콜렛케익", "티라미수", "브레드용빵" };

		// 19-07-18까지
		String[] jdate = { "2019-07-01", "2019-07-02", "2019-07-03", "2019-07-04", "2019-07-05", "2019-07-06",
				"2019-07-07", "2019-07-08", "2019-07-09", "2019-07-10", "2019-07-11", "2019-07-12", "2019-07-13",
				"2019-07-14", "2019-07-15", "2019-07-16", "2019-07-17", "2019-07-18" };

		String sql = "INSERT INTO TBLINVENTORY (inventorySeq, inventoryType, inventoryName, inventoryCount, operateDate) "
				+ "values (inventorySeq.nextval, ?, ?, ?, ?)";

		try {

			DBUtil util = new DBUtil();
			Connection conn = util.connect();
			PreparedStatement stat = conn.prepareStatement(sql);

			for (int i = 0; i < 18; i++) {

				stat.setString(4, jdate[i]);

				ArrayList<String> check = new ArrayList<String>(); // check list 생성 이 날짜에서 중복되는게 없어야 함.

				for (int j = 0; j < 62; j++) {

					String typetest = "";
					String insert = "";

					// rnd 조건 확인
					boolean isThere = true; // boolean 값 만들고
					Random rnd = new Random();

					while (isThere) {

						isThere = false; // 돌때마다 초기화

						typetest = inventoryType[rnd.nextInt(inventoryType.length)];

						if (typetest.equals("001")) {

							insert = food[rnd.nextInt(food.length)];

						} else if (typetest.equals("002")) {

							insert = product[rnd.nextInt(product.length)];

						} else if (typetest.equals("003")) {

							insert = etc[rnd.nextInt(etc.length)];
						}

						for (String test : check) {

							// check리스트 확인. 걸리는게 있으면 다시 돌림
							if (test.equals(insert)) {
								isThere = true;
							}

						}

					}

					check.add(insert);

					stat.setString(1, typetest);
					stat.setString(2, insert);
					stat.setInt(3, rnd.nextInt(30));
					stat.executeUpdate();
				}

			}

			System.out.println("Insert OK!");

		} catch (Exception e) {
			System.out.println("GenereatePosDummy.inventory : " + e.toString());
		}

	}// method: inventory

}// Class: GeneratePosDummy

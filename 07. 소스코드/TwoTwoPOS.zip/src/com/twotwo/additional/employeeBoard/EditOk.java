package com.twotwo.additional.employeeBoard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/additional/employeeBoard/editok.do")
public class EditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		req.setCharacterEncoding("UTF-8");
		
		BoardDTO dto = new BoardDTO();
		
		int employeeboardSeq = Integer.parseInt(req.getParameter("employeeboardSeq"));
		dto.setSubject(req.getParameter("subject"));
		dto.setContent(req.getParameter("content"));
		dto.setEmployeeboardOption(req.getParameter("employeeboardOption"));
		dto.setEmployeeboardSeq(employeeboardSeq);
		
		BoardDAO dao = new BoardDAO();
		
		int result  = -1;
		System.out.println("employeeboardSeq : " + employeeboardSeq);
		System.out.println("session.getAttribute(\"id\") : " + session.getAttribute("id"));
		if (dao.isOwner(employeeboardSeq, session.getAttribute("id").toString())) {
			result = dao.edit(dto);
			System.out.println(result);
		} else {
			result = 2;
		}
		
		if (result == 1) {
			resp.sendRedirect("/TwoTwoPOS/additional/employeeBoard/employeeboard.do"); //목록
		} else {
			resp.getWriter().print("<script> alert('Failed'); history.back(); </script>");
			resp.getWriter().close();
		}
		
	}
	
}


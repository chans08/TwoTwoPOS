package com.twotwo.salesRegister;

public class Test {
	public static void main(String[] args) {
		int firstkeySeq = 0;
		int intcategorySeq = 10;
		if (intcategorySeq % 10 == 0) {
			firstkeySeq = intcategorySeq / 10;
		} else {
			firstkeySeq = intcategorySeq / 10 + 1;
		}
		
		System.out.println(firstkeySeq);
	}
}


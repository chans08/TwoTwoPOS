package com.twotwo.inquiry;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/inquiry/salesInquiryData.do")
public class SalesInquiryData extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session = req.getSession();
		req.setCharacterEncoding("UTF-8");
		
		String receipt = req.getParameter("receipt");
		
		if(receipt.equals("disabled")) {
			
			//조회할 판매내역 일자
			String year1 = req.getParameter("datePick1").substring(6, 10);
			String month1 = req.getParameter("datePick1").substring(0, 2);
			String date1 = req.getParameter("datePick1").substring(3, 5);
					
			String year2 = req.getParameter("datePick2").substring(6, 10);
			String month2 = req.getParameter("datePick2").substring(0, 2);
			String date2 = req.getParameter("datePick2").substring(3, 5);
			
			String operateDate1 = year1 + "-" + month1 + "-" + date1;
			String operateDate2 = year2 + "-" + month2 + "-" + date2;
			
		//---------------------------------------------------------------------------------------------
			
			InquiryDAO dao = new InquiryDAO();
			
			//판매내역 리스트
			ArrayList<VwSalesInquiryDTO> inquiryList = dao.salesInquiry(operateDate1, operateDate2);
			session.setAttribute("inquiryList", inquiryList);		

			//JSP 호출
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/inquiry/salesInquiry.jsp");
			dispatcher.forward(req, resp);
			
		} else if (receipt.equals("enabled")) {
			
			//영수증 출력할 주문번호와 주문날짜
			String orderNumber = req.getParameter("orderNumber");
			String receiptDate = req.getParameter("receiptDate");
			
		//---------------------------------------------------------------------------------------------
			
			//판매내역 영수증
			InquiryDAO dao = new InquiryDAO();
			
			ArrayList<VwSalesReceiptDTO> inquiryReceipt = dao.salesReceipt(orderNumber, receiptDate);	
			
			req.setAttribute("inquiryReceipt", inquiryReceipt);
			
			//JSP 호출
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/inquiry/salesInquiry.jsp");
			dispatcher.forward(req, resp);
			
		}
		
	}//method : doGet

}//Class : SalesInquiryData

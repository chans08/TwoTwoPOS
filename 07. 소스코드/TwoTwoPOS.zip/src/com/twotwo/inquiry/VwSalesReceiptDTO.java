package com.twotwo.inquiry;

public class VwSalesReceiptDTO {

	private String orderNumber;
	private String operateDate;
	private String operateDay;
	private String itemName;
	private String itemPrice;
	private String orderAmount;
	private String posNum;
	
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOperateDate() {
		return operateDate;
	}
	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}
	public String getOperateDay() {
		return operateDay;
	}
	public void setOperateDay(String operateDay) {
		this.operateDay = operateDay;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(String orderAmount) {
		this.orderAmount = orderAmount;
	}
	public String getPosNum() {
		return posNum;
	}
	public void setPosNum(String posNum) {
		this.posNum = posNum;
	}
	
}//Class: VwSalesReceiptDTO

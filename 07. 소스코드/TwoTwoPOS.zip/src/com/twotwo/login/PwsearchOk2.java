package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/pwsearchok2.do")
public class PwsearchOk2 extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//PwsearchOk2.java
		// 1. 데이터 가져오기
		
		req.setCharacterEncoding("UTF-8");
		String pwHintq = req.getParameter("pwhintq");
		String pwHintA = req.getParameter("pwhinta");
		
		VwEmployee dto = new VwEmployee();
		
		dto.setPwHintA(pwHintA);
		
		// 2. DB 작업 > DAO 위임(select where)
		EmployeeDAO dao = new EmployeeDAO();
		
		VwEmployee pwhint = dao.pwHintSearch(dto);
		
		
		// 3. 결과 반환
		if(pwhint != null) {
			req.setAttribute("userpw", pwhint.getUserPw());
			req.setAttribute("id", pwhint.getUserId());

			} else {
				req.setAttribute("userpw", null);
				req.setAttribute("pwhintq", pwHintq);
			}

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/pwsearchok2.jsp");
		dispatcher.forward(req, resp);
	}
}

package com.twotwo.home;

public class OperateDateDTO {

	private String operateDateSeq;
	private String operatePoint;
	private String weatherName;
	private String temperature;
	
	public String getOperateDateSeq() {
		return operateDateSeq;
	}
	public void setOperateDateSeq(String operateDateSeq) {
		this.operateDateSeq = operateDateSeq;
	}
	public String getOperatePoint() {
		return operatePoint;
	}
	public void setOperatePoint(String operatePoint) {
		this.operatePoint = operatePoint;
	}
	public String getWeatherName() {
		return weatherName;
	}
	public void setWeatherName(String weatherName) {
		this.weatherName = weatherName;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	
}//Class: OperateDateDTO

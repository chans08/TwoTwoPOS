package com.twotwo.login;

public class EmployeeDTO {
	
	private int employeeSeq;
	private String userId;
	private String userPw;
	private String name;
	private String position;
	private String blNumber;
	private String birthDate;
	private String gender;
	private String email;
	private String address;
	private String tel;
	private int workTime;
	private String ibsadate;
	private String quitdate;
	private String pwHintQ;
	private String pwHintA;
	private int healthCertificate;
	private int educationComplete;
	private String pic;
	private int branchSeq;
	
	public int getEmployeeSeq() {
		return employeeSeq;
	}
	public void setEmployeeSeq(int employeeSeq) {
		this.employeeSeq = employeeSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserPw() {
		return userPw;
	}
	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getBlNumber() {
		return blNumber;
	}
	public void setBlNumber(String blNumber) {
		this.blNumber = blNumber;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getWorkTime() {
		return workTime;
	}
	public void setWorkTime(int workTime) {
		this.workTime = workTime;
	}
	public String getIbsadate() {
		return ibsadate;
	}
	public void setIbsadate(String ibsadate) {
		this.ibsadate = ibsadate;
	}
	public String getQuitdate() {
		return quitdate;
	}
	public void setQuitdate(String quitdate) {
		this.quitdate = quitdate;
	}
	public String getPwHintQ() {
		return pwHintQ;
	}
	public void setPwHintQ(String pwHintQ) {
		this.pwHintQ = pwHintQ;
	}
	public String getPwHintA() {
		return pwHintA;
	}
	public void setPwHintA(String pwHintA) {
		this.pwHintA = pwHintA;
	}
	public int getHealthCertificate() {
		return healthCertificate;
	}
	public void setHealthCertificate(int healthCertificate) {
		this.healthCertificate = healthCertificate;
	}
	public int getEducationComplete() {
		return educationComplete;
	}
	public void setEducationComplete(int educationComplete) {
		this.educationComplete = educationComplete;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public int getBranchSeq() {
		return branchSeq;
	}
	public void setBranchSeq(int branchSeq) {
		this.branchSeq = branchSeq;
	}
	
	
	
	
}

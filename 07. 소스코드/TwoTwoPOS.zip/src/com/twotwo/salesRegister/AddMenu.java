package com.twotwo.salesRegister;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/salesRegister/addmenu.do")
public class AddMenu extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//AddMenuName.java
		HttpSession session = req.getSession();
		
		String categorySeq = req.getParameter("categorySeq"); //8
		String menuSeq = req.getParameter("menuSeq"); //1
		session.setAttribute("categorySeq", categorySeq);
		session.setAttribute("menuSeq", menuSeq);
		
		
		SalesRegisterDAO dao = new SalesRegisterDAO();
		int existMenuSeq = dao.existMenuSeq(categorySeq, menuSeq);
		ItemDTO dto;
		if (existMenuSeq == 1) {
			dto = dao.getItem(categorySeq, menuSeq);
		
		} else {//existMenuSeq == 0
			
			dto = new ItemDTO();
			dto.setCategorySeq(categorySeq);
			String categoryName = dao.getCategoryName(dto);
			dto.setCategoryName(categoryName);
			dto.setMenuSeq(menuSeq);
		}
		req.setAttribute("dto", dto);
		req.setAttribute("existMenuSeq", existMenuSeq);

		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/salesRegister/addmenu.jsp");
		dispatcher.forward(req, resp);
		
	}
}

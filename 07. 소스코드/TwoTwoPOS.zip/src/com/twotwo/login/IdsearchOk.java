package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/idsearchok.do")
public class IdsearchOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//IdsearchOk.java
		// 1. 데이터 가져오기
		
		req.setCharacterEncoding("UTF-8");

		String name = req.getParameter("name");
		String birthDate = req.getParameter("birthdate");
		
		VwEmployee dto = new VwEmployee();
		
		dto.setName(name);
		dto.setBirthDate(birthDate);

		// 2. DB 작업 > DAO 위임(select where)
		EmployeeDAO dao = new EmployeeDAO();
		
		//int result = dao.idCheck(dto);
		VwEmployee id = dao.idSearch(dto);
		
		//System.out.println(id);
		// 3. 결과 반환
		if(id != null) {
		req.setAttribute("id", id.getUserId());
		req.setAttribute("name", id.getName());
		} else {
			req.setAttribute("id", null);
		}
		// 4. JSP 호출

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/idsearchok.jsp");
		dispatcher.forward(req, resp);
	}
}
package com.twotwo.home;

public class TodoListDTO {
	
	private String todoListSeq;
	private String todoListSubject;
	private String todoListContent;
	private String todoChecked;
	private String todoCheckedTime;
	
	public String getTodoListSeq() {
		return todoListSeq;
	}
	public void setTodoListSeq(String todoListSeq) {
		this.todoListSeq = todoListSeq;
	}
	public String getTodoListSubject() {
		return todoListSubject;
	}
	public void setTodoListSubject(String todoListSubject) {
		this.todoListSubject = todoListSubject;
	}
	public String getTodoListContent() {
		return todoListContent;
	}
	public void setTodoListContent(String todoListContent) {
		this.todoListContent = todoListContent;
	}
	public String getTodoChecked() {
		return todoChecked;
	}
	public void setTodoChecked(String todoChecked) {
		this.todoChecked = todoChecked;
	}
	public String getTodoCheckedTime() {
		return todoCheckedTime;
	}
	public void setTodoCheckedTime(String todoCheckedTime) {
		this.todoCheckedTime = todoCheckedTime;
	}
	
}//Class: TodoListDTO

package com.twotwo.additional.employeeBoard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/additional/employeeBoard/view.do")
public class View extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		//1.
		String employeeboardSeq = req.getParameter("employeeboardSeq");
		
		//2.
		BoardDAO dao = new BoardDAO();
		
		//3. 게시물 조회수 증가하기(+1)
		if (session.getAttribute("read") == null || session.getAttribute("read").toString().equals("n")) {
			dao.addReadCount(employeeboardSeq);
			session.setAttribute("read", "y");
		}
			
			//글보기
			BoardDTO dto = dao.get(employeeboardSeq);
			
			String content = dto.getContent();
			
			//C. 글내용에 태그 적용 안함 처리하기
			if (dto.getEmployeeboardOption().equals("n")) {
				//<a> -> &lt;a&gt;
				content = content.replace("<", "&lt;").replace(">", "&gt;");
				dto.setContent(content);
			}
			
			//D. 태그 적용 유무와 관계없이 <script>, <script type="">, <script language=""> 비활성화
			content = content.replace("<script", "&lt;script").replace("</script>", "&lt;/script&gt;");
			dto.setContent(content);
			
			//B. 글내용에 엔터값 처리하기
			content = content.replace("\r\n", "<br>");
			dto.setContent(content);
			
			dao.close();
			
			req.setAttribute("dto", dto);
			
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/additional/employeeBoard/view.jsp");
			dispatcher.forward(req, resp);
			
	}//method: doGet
		
}//Class: View




package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/pwsearchok.do")
public class PwsearchOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//PwsearchOk.java
		// 1. 데이터 가져오기
		
		req.setCharacterEncoding("UTF-8");
		String id = req.getParameter("id");
		
		VwEmployee dto = new VwEmployee();
		
		dto.setUserId(id);
		
		// 2. DB 작업 > DAO 위임(select where)
		EmployeeDAO dao = new EmployeeDAO();
		
		//int result = dao.idCheck(dto);
		VwEmployee userpw = dao.pwSearch(dto);
		
	

		// 3. 결과 반환
		if(userpw != null) {
			req.setAttribute("userpw", userpw.getUserPw());
			req.setAttribute("id", userpw.getUserId());
			req.setAttribute("pwhintq", userpw.getPwHintQ());
			req.setAttribute("pwhinta", userpw.getPwHintA());
			
			} else if(userpw == null) {
				req.setAttribute("userpw", null);
			}
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/pwsearchok.jsp");
		dispatcher.forward(req, resp);
	}
}

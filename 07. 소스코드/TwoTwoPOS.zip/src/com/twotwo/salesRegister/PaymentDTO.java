package com.twotwo.salesRegister;

public class PaymentDTO {
	private String paymentSeq;
	private String orderNumber;//주문번호
	private String itemSeq;//판매상품번호
	private String itemName;//상품명
	private int itemPrice;//가격
	private int orderAmount;//판매개수
	private int entirePayAmount;
	private int payAmount;
	private int discountAmount;
	private int card;
	private int cash;
	private String refund;
	private String takeout;
	private String memberSeq;
	private String cardCompanySeq;
	private String branchSeq;
	private String operateDate;
	
	public String getPaymentSeq() {
		return paymentSeq;
	}
	public void setPaymentSeq(String paymentSeq) {
		this.paymentSeq = paymentSeq;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getItemSeq() {
		return itemSeq;
	}
	public void setItemSeq(String itemSeq) {
		this.itemSeq = itemSeq;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public int getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(int orderAmount) {
		this.orderAmount = orderAmount;
	}
	public int getEntirePayAmount() {
		return entirePayAmount;
	}
	public void setEntirePayAmount(int entirePayAmount) {
		this.entirePayAmount = entirePayAmount;
	}
	public int getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(int payAmount) {
		this.payAmount = payAmount;
	}
	public int getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(int discountAmount) {
		this.discountAmount = discountAmount;
	}
	public int getCard() {
		return card;
	}
	public void setCard(int card) {
		this.card = card;
	}
	public int getCash() {
		return cash;
	}
	public void setCash(int cash) {
		this.cash = cash;
	}
	public String getRefund() {
		return refund;
	}
	public void setRefund(String refund) {
		this.refund = refund;
	}
	public String getTakeout() {
		return takeout;
	}
	public void setTakeout(String takeout) {
		this.takeout = takeout;
	}
	public String getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(String memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getCardCompanySeq() {
		return cardCompanySeq;
	}
	public void setCardCompanySeq(String cardCompanySeq) {
		this.cardCompanySeq = cardCompanySeq;
	}
	public String getBranchSeq() {
		return branchSeq;
	}
	public void setBranchSeq(String branchSeq) {
		this.branchSeq = branchSeq;
	}
	public String getOperateDate() {
		return operateDate;
	}
	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}
	
	
	
}

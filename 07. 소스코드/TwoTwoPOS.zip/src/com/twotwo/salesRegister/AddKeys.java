package com.twotwo.salesRegister;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/salesRegister/addkeys.do")
public class AddKeys extends HttpServlet {
	
	private String categorySeq;
	private String menuSeq;
	int firstkeySeq;
	int mfirstkeySeq;
	private String keySettingMode;
	private String menuSettingMode;
	/**
	 * location -> categorySeq 만들 누적 변수 lcToCs
	 */
	private String lcToCs;
	/**
	 * mlocation -> menuSeq 만들 누적 변수 mlcToMs
	 */
	private String mlcToMs;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		SalesRegisterDAO dao = new SalesRegisterDAO();
		
		//현재 페이지의 첫번째 키의 카테고리 번호 초기화 
		if (session.getAttribute("firstkeySeq") == null) {
			session.setAttribute("firstkeySeq", 1);
			firstkeySeq = 1;
		}
		
		//현재 페이지의 첫번째 키의 메뉴 번호 초기화 
		if (session.getAttribute("mfirstkeySeq") == null) {
			session.setAttribute("mfirstkeySeq", 1);
			mfirstkeySeq = 1;
		}
		
		
		//현재 페이지의 카테고리 번호 초기화 또는 가져오기
		
		if (session.getAttribute("categorySeq") == null) {
			categorySeq = "1";
			session.setAttribute("categorySeq", 1);
		} else {
			if (req.getParameter("categorySeq") != null) {
				session.setAttribute("categorySeq", req.getParameter("categorySeq"));
			}
			categorySeq = session.getAttribute("categorySeq").toString();
		}
		
		//현재 페이지의 메뉴 번호 초기화 또는 가져오기
		
		if (session.getAttribute("menuSeq") == null) {
			menuSeq = "1";
			session.setAttribute("menuSeq", 1);
		} else {
			if (req.getParameter("menuSeq") != null) {
				session.setAttribute("menuSeq", req.getParameter("menuSeq"));
			}
			menuSeq = session.getAttribute("menuSeq").toString();
		}
		
		//location -> categorySeq 만들 누적 변수 lcToCs
		if (session.getAttribute("lcToCs") == null) {
			lcToCs = "0";
			session.setAttribute("lcToCs", 0);
		} else {
			lcToCs = session.getAttribute("lcToCs").toString();
		}
		
		
		//mlocation -> menuSeq 만들 누적 변수 mlcToMs
		if (session.getAttribute("mlcToMs") == null) {
			mlcToMs = "0";
			session.setAttribute("mlcToMs", 0);
		} else {
			mlcToMs = session.getAttribute("mlcToMs").toString();
		}
		
		//카테고리 이동
		String moveCategory = req.getParameter("moveCategory");
		if (moveCategory != null && moveCategory.contentEquals("1")) {
			categorySeq = req.getParameter("categorySeq");
			session.setAttribute("categorySeq", categorySeq);
			
			menuSeq = 1 + "";
			session.setAttribute("menuSeq", menuSeq);
		}
		
		firstkeySeq = Integer.parseInt(lcToCs) * 10 + 1;
		mfirstkeySeq = Integer.parseInt(mlcToMs) * 34 + 1;
		
		keySettingMode = req.getParameter("keySettingMode");
		menuSettingMode = req.getParameter("menuSettingMode");
		String next = req.getParameter("next");
		String prev = req.getParameter("prev");
		String mnext = req.getParameter("mnext");
		String mprev = req.getParameter("mprev");
		
		
		//key설정 모드 on || off
		if (keySettingMode != null) {
			session.setAttribute("keySettingMode", keySettingMode);
		}
		
		//key설정 모드 on!!
		if (keySettingMode != null && keySettingMode.equals("on")) {
			
		}
		
		//메뉴 설정 모드 on || off
		if (menuSettingMode != null) {
			session.setAttribute("menuSettingMode", menuSettingMode);
		}
		
		//메뉴 설정 모드 on!!
		if (menuSettingMode != null && menuSettingMode.equals("on")) {
			
		}
		
		
		//---------------------------------------------------------------------------------
		//카테고리 목록 다음 키 누르면
		if (next != null && next.contentEquals("1")) {
			
			//lcToCs 누적
			int intlcToCs = Integer.parseInt(lcToCs);
			intlcToCs++;
			lcToCs = intlcToCs + "";
			session.setAttribute("lcToCs", lcToCs);
			
			int resultExistNextPage = dao.existNextPage(firstkeySeq);
			int nextkeySeq = firstkeySeq + 10;

			if (resultExistNextPage == 0) { //다음페이지가 존재하지 않으면
				int resultAddCategoryPage = dao.addCategoryPage(nextkeySeq);
				
			}
			
			firstkeySeq = nextkeySeq;
			session.setAttribute("firstkeySeq", nextkeySeq);

			categorySeq = firstkeySeq + "";
			session.setAttribute("categorySeq", categorySeq);
			
		}
		
		//카테고리 목록 이전 키 누르면
		if (prev != null && prev.contentEquals("1")) {
			
			if (Integer.parseInt(categorySeq) >= 11) { //이전페이지가 존재하면
				
				//누적
				int intlcToCs = Integer.parseInt(lcToCs);
				intlcToCs--;
				lcToCs = intlcToCs + "";
				session.setAttribute("lcToCs", lcToCs);
				
				int prevkeySeq = firstkeySeq - 10;
				
				firstkeySeq = prevkeySeq;
				session.setAttribute("firstkeySeq", prevkeySeq);
				
				categorySeq = firstkeySeq + "";
				session.setAttribute("categorySeq", categorySeq);
			}
			
		}
		
		//카테고리 목록 가져오기
		ArrayList<ItemCategoryDTO> itemCategorylist = dao.itemCategorylist(firstkeySeq);
		
		//최대 카테고리 페이지 가져오기
		int maxCategoryPage = dao.getMaxCategoryPage();
		
		//현재 카테고리 페이지 가져오기
		int currentCategoryPage = firstkeySeq;
		if (currentCategoryPage >= 10) {
			currentCategoryPage /= 10;
			++currentCategoryPage;
		}
		//---------------------------------------------------------------------------------
		
		
		
		//메뉴 목록 다음 키 누르면
		if (mnext != null && mnext.contentEquals("1")) {
			
			//누적
			int intmlcToMs = Integer.parseInt(mlcToMs);
			intmlcToMs++;
			mlcToMs = intmlcToMs + "";
			session.setAttribute("mlcToMs", mlcToMs);
			
			int resultExistMnextPage = dao.existMnextPage(mfirstkeySeq, categorySeq);
			int mnextkeySeq = mfirstkeySeq + 34;

			if (resultExistMnextPage == 0) { //다음페이지가 존재하지 않으면
				int resultAddMenuPage = dao.addMenuPage(mnextkeySeq, categorySeq);
			}
			
			mfirstkeySeq = mnextkeySeq;
			session.setAttribute("mfirstkeySeq", mnextkeySeq);
			
			menuSeq = mfirstkeySeq + "";
			session.setAttribute("menuSeq", menuSeq);
		}

		//메뉴 목록 이전 키 누르면
		if (mprev != null && mprev.contentEquals("1")) {
			if (Integer.parseInt(menuSeq) >= 35) { //이전페이지가 존재하면
				
				//누적
				int intmlcToMs = Integer.parseInt(mlcToMs);
				intmlcToMs--;
				mlcToMs = intmlcToMs + "";
				session.setAttribute("mlcToMs", mlcToMs);
				
				int mprevkeySeq = mfirstkeySeq - 34;
				
				mfirstkeySeq = mprevkeySeq;
				session.setAttribute("mfirstkeySeq", mprevkeySeq);
				
				menuSeq = mfirstkeySeq + "";
				session.setAttribute("menuSeq", menuSeq);
			}
			
		}
		
		
		
		//메뉴 목록 가져오기
		ArrayList<ItemDTO> itemlist = dao.itemlist(mfirstkeySeq, categorySeq);
		
		
		//최대 메뉴 페이지 가져오기
		int maxMenuPage = dao.getMaxMenuPage(categorySeq);
		
		//현재 메뉴 페이지 가져오기
		int currentItemPage = mfirstkeySeq;
		if (currentItemPage >= 34) {
			currentItemPage /= 34;
			++currentItemPage;
		}
		
		req.setAttribute("itemCategorylist", itemCategorylist);
		req.setAttribute("maxCategoryPage", maxCategoryPage);
		req.setAttribute("currentCategoryPage", currentCategoryPage);
		req.setAttribute("next", next); 
		req.setAttribute("prev", prev); 
		
		req.setAttribute("itemlist", itemlist);
		req.setAttribute("maxMenuPage", maxMenuPage);
		req.setAttribute("currentItemPage", currentItemPage);
		req.setAttribute("mnext", mnext); 
		req.setAttribute("mprev", mprev); 
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/salesRegister/addkeys.jsp");
		dispatcher.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		
		HttpSession session = req.getSession();
		
		String addkeyname = req.getParameter("addkeyname");
		String addmenu = req.getParameter("addmenu");
		
		//add itemCategory 등록
		if (addkeyname != null && addkeyname.contentEquals("1")) {
			
			categorySeq = req.getParameter("categorySeq");
			session.setAttribute("categorySeq", categorySeq);
			
			
			mfirstkeySeq = 1;
			session.setAttribute("mfirstkeySeq", "1");
			
			menuSeq = "1";
			session.setAttribute("menuSeq", "1");
			
			String categoryName = req.getParameter("categoryName");
			
			ItemCategoryDTO itemCategoryDTO = new ItemCategoryDTO();
			itemCategoryDTO.setCategorySeq(categorySeq);
			itemCategoryDTO.setCategoryName(categoryName);
			
			SalesRegisterDAO dao = new SalesRegisterDAO();
			
			int resultItemCategory;
			int existCategorySeq = dao.existCategorySeq(categorySeq);
			
			if (existCategorySeq == 0) {//categoryseq 없으면
				resultItemCategory = dao.addItemCategory(itemCategoryDTO);
			} else {//categoryseq 있으면
				resultItemCategory = dao.editItemCategory(itemCategoryDTO);
			}
			
			
			req.setAttribute("resultItemCategory", resultItemCategory);

			PrintWriter writer = resp.getWriter();
			
			writer.print("<script>opener.location.href='/TwoTwoPOS/salesRegister/addkeys.do'; window.close();</script>");
			writer.close();
		}
		
		//add 메뉴 등록
		if (addmenu != null && addmenu.contentEquals("1")) {
			
			categorySeq = req.getParameter("categorySeq");
			String categoryName = req.getParameter("categoryName");
			menuSeq = req.getParameter("menuSeq");
			String itemName = req.getParameter("itemName");
			String itemPrice = req.getParameter("itemPrice");
			
			int existMenuSeq = Integer.parseInt(req.getParameter("existMenuSeq"));
			
			session.setAttribute("menuSeq", menuSeq);
			
			ItemDTO itemDTO = new ItemDTO();
			itemDTO.setCategorySeq(categorySeq);
			itemDTO.setCategoryName(categoryName);
			itemDTO.setMenuSeq(menuSeq);
			itemDTO.setItemName(itemName);
			itemDTO.setItemPrice(Integer.parseInt(itemPrice));
			
			SalesRegisterDAO dao = new SalesRegisterDAO();
			
			int resultAddItem;
			if (existMenuSeq == 0) {//등록된 item 없었으면
				resultAddItem = dao.addItem(itemDTO);
			} else {//등록된 item 있었으면
				resultAddItem = dao.editItem(itemDTO);
			}
			
			req.setAttribute("resultAddItem", resultAddItem);

			PrintWriter writer = resp.getWriter();
			
			writer.print("<script>opener.location.href='/TwoTwoPOS/salesRegister/addkeys.do'; window.close();</script>");
			writer.close();
		}
		
	}
}

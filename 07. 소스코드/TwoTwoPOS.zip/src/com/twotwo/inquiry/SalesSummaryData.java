package com.twotwo.inquiry;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/inquiry/salesSummaryData.do")
public class SalesSummaryData extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String year = req.getParameter("datePick").substring(6, 10);
		String month = req.getParameter("datePick").substring(0, 2);
		String date = req.getParameter("datePick").substring(3, 5);
		
		String operateDate = year + "-" + month + "-" + date;
		
		InquiryDAO dao = new InquiryDAO();
		
		ArrayList<VwSalesSummaryDTO> summaryList = dao.salesAll(operateDate);
		ArrayList<VwSalesGraphDTO> summaryGraph = dao.salesGraph(operateDate);
		
		req.setAttribute("payList", summaryList);
		req.setAttribute("summaryGraph", summaryGraph);

		//JSP 호출
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/inquiry/salesSummary.jsp");
		dispatcher.forward(req, resp);

	}//method : doGet

}//Class : SalesSummaryData

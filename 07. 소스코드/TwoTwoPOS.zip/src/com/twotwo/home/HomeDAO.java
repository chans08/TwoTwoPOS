package com.twotwo.home;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class HomeDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public HomeDAO() {	
		DBUtil util = new DBUtil();
		conn = util.connect();	
	}
	
//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<VwDailyWeatherDTO> dailyWeather() {
		
		try {

			String sql = "SELECT * FROM vwdailyweather";
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<VwDailyWeatherDTO> weatherList = new ArrayList<VwDailyWeatherDTO>();
			
			while(rs.next()) {
				
				VwDailyWeatherDTO dto = new VwDailyWeatherDTO();
				dto.setOperateDate(rs.getString("operateDate"));
				dto.setDayName(rs.getString("dayName"));
				dto.setWeatherName(rs.getString("weatherName"));
				dto.setTemperature(rs.getString("temperature"));
				weatherList.add(dto);
				
			}
			
			return weatherList;
			
		} catch (Exception e) {
			System.out.println("HomeDAO.dailyWeather : " + e.toString());
		}

		return null;
		
	}//method: dailyWeather

//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<TodoListDTO> todoList() {
		
		try {

			String sql = "SELECT * FROM tblTodoList";
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<TodoListDTO> weatherList = new ArrayList<TodoListDTO>();
			
			while(rs.next()) {
				
				TodoListDTO dto = new TodoListDTO();
				dto.setTodoListSeq(rs.getString("todoListSeq"));
				dto.setTodoListSubject(rs.getString("todoListSubject"));
				dto.setTodoListContent(rs.getString("todoListContent"));
				dto.setTodoChecked(rs.getString("todoChecked"));
				dto.setTodoCheckedTime(rs.getString("todoCheckedTime"));
				weatherList.add(dto);
				
			}
			
			return weatherList;

		} catch (Exception e) {
			System.out.println("HomeDAO.todoList : " + e.toString());
		}
		
		return null;
		
	}//method: todoList

//-----------------------------------------------------------------------------------------------------------
	
	public void todoEnable(String todoListSeq) {
		
		try {

			String sql = "UPDATE tblTodoList SET todoChecked = 1, todoCheckedTime = sysdate "
							+ "WHERE todoListSeq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, todoListSeq);
			
			stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("HomeDAO.todoEnable : " + e.toString());
		}
		
	}//method: todoEnable

//-----------------------------------------------------------------------------------------------------------
	
	public void todoDisable(String todoListSeq) {
		
		try {

			String sql = "UPDATE tblTodoList SET todoChecked = 0, todoCheckedTime = sysdate "
							+ "WHERE todoListSeq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, todoListSeq);
			
			stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("HomeDAO.todoDisable : " + e.toString());
		}
		
	}//method: todoDisable
	
	
}//Class: HomeDAO





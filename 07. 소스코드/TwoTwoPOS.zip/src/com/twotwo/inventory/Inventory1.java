package com.twotwo.inventory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/inventory/inventory1.do")
public class Inventory1 extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//inventory1.java
		//inventory1.do
		//inventory1.do?begin=2017-01-01&end=2017-01-10

		Calendar cal = Calendar.getInstance();
	
		int year = cal.get(Calendar.YEAR); 
        int month = cal.get(Calendar.MONTH)+1; 
        int day = cal.get(Calendar.DATE); 

        //System.out.println(year);
        //System.out.println(month);
        //System.out.println(day);

        //---------------------------------------------------
        
        
		InventoryDAO dao = new InventoryDAO();
		
		String begin = req.getParameter("begin");
		String end= req.getParameter("end");
		
		if (begin == null && end == null) {
			begin = year+"-"+month+"-"+(day-6);//Calendar
			end = year+"-"+month+"-"+day;
		}
		
		// form태그 써서 받아옴, '/' -> '-'
		// 07/17/2019
		// name으로 파라메터 사용하면 되는 데 > begin / end 사용하면 된다.
		
		if(begin.indexOf('/') > -1) {			
			String[] temp1 = begin.split("/");		
			begin = temp1[2] + '-' + temp1[0] + '-' + temp1[1];		
		} 
		
		if(end.indexOf('/') > -1 ) {
			String[] temp2 = end.split("/");	
			end = temp2[2] + '-' + temp2[0] + '-' + temp2[1];	
		}
	
		//-----------------------------------------------------
		
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("begin", begin);
		map.put("end", end);
		
		
		ArrayList<ArrayList<InventoryDTO>> list = dao.getInvenList(map);
		
		req.setAttribute("list", list);
		req.setAttribute("begin", begin);
		req.setAttribute("end", end);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/inventory/inventory1.jsp");
		dispatcher.forward(req, resp);

	}

}
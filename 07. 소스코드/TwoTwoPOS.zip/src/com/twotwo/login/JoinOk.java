package com.twotwo.login;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@WebServlet("/joinok.do")
public class JoinOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//JoinOk.java
		//0. MultipartRequest 생성
		//1. 데이터가져오기
		//2. 첨부 파일 처리
		//3. DB 작업 > DAO 위임(insert)
		//4. 결과 반환 > JSP 호출
		
		req.setCharacterEncoding("UTF-8");
		
		//cos.jar
		MultipartRequest multi = new MultipartRequest(
												req,
												req.getRealPath("/pic"),
												1024 * 1024 * 10,
												"UTF-8",
												new DefaultFileRenamePolicy()
												);
		
		String id = multi.getParameter("jid");
		String pw = multi.getParameter("jpw");
		String name = multi.getParameter("jname");
		String position = multi.getParameter("jposition");
		String blnumber = multi.getParameter("jblnumber");
		String birthDate = multi.getParameter("jbirthdate");
		String gender = multi.getParameter("jgender");
		String email = multi.getParameter("jemail");
		String tel = multi.getParameter("jtel1") + "-"+ multi.getParameter("jtel2")+ "-"+ multi.getParameter("jtel3");
		String pwhintq = multi.getParameter("jpwhintq");
		String pwhinta = multi.getParameter("jpwhinta"); 
		String pic = multi.getFilesystemName("jpic");
		
		if(pic != null) {
			//man_01.png > hong.png
			File file = new File(req.getRealPath("/pic") + "\\" + pic);
			System.out.println(file.exists());
			File file2 = new File(req.getRealPath("/pic") + "\\" + id + ".jpg");
			file.renameTo(file2); //사진을 아이디로 이름 바꾸기
			
			pic = id + ".png";
			 
		} else {
			pic = "profile.png";
		}
		
		VwEmployee dto = new VwEmployee();
		
		dto.setUserId(id);
		dto.setUserPw(pw);
		dto.setName(name);
		dto.setPosition(position);
		dto.setBlNumber(blnumber);
		dto.setBirthDate(birthDate);
		dto.setGender(gender);
		dto.setEmail(email);
		dto.setTel(tel);
		dto.setPwHintQ(pwhintq);
		dto.setPwHintA(pwhinta);
		dto.setPic(pic);
		
		EmployeeDAO dao = new EmployeeDAO();
		
		dao.insertBranch(dto);
		int result = dao.join(dto);
		
		req.setAttribute("result", result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/joinok.jsp");
		dispatcher.forward(req, resp);
	}
}
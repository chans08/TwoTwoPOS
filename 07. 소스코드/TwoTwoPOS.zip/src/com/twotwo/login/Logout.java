package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login/logout.do")
public class Logout extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//LogOut.java
		//1. 인증 티켓 제거하기
		//2. 개인 정보 제거하기
		//3. JSP 호출
		
		//1. 
		HttpSession session = req.getSession();
		session.invalidate(); // 세션 전체를 날려버림


		//2. 
		/*
			session.removeAttribute("id");
			session.removeAttribute("pw");
			session.removeAttribute("name");
			session.removeAttribute("position");
			session.removeAttribute("blNumber");
			session.removeAttribute("birthdate");
			session.removeAttribute("gender");
			session.removeAttribute("ibsadate");
			session.removeAttribute("pic");
			session.removeAttribute("cafename");
		*/
		
		 // 로그인 유지 쿠키 삭제
		
		  Cookie[] cookies = req.getCookies(); 
		  if(cookies != null)
		  { 
			  for(Cookie cookie :cookies)
			  { 
				  //if(cookie.getName().equals("id")){ 
					  	cookie.setMaxAge(0);
					  	cookie.setPath("/"); 
					  	resp.addCookie(cookie); } 
				 //} 
		  }
		 
		
		/*
		 * // 전체 쿠키 삭제하기 Cookie[] cookies = req.getCookies() ;
		 * 
		 * if(cookies != null){ for(int i=0; i < cookies.length; i++){
		 * 
		 * // 쿠키의 유효시간을 0으로 설정하여 만료시킨다 cookies[i].setMaxAge(0) ;
		 * 
		 * // 응답 헤더에 추가한다 resp.addCookie(cookies[i]) ; } }
		 */


	
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/logout.jsp");
		dispatcher.forward(req, resp);
	}
}

package com.twotwo.inquiry;

public class VwSalesInquiryDTO {

	private String no;
	private String operateDate;
	private String orderNumber;
	private String posNum;
	private String entirePayAmount;
	
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getOperateDate() {
		return operateDate;
	}
	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getPosNum() {
		return posNum;
	}
	public void setPosNum(String posNum) {
		this.posNum = posNum;
	}
	public String getEntirePayAmount() {
		return entirePayAmount;
	}
	public void setEntirePayAmount(String entirePayAmount) {
		this.entirePayAmount = entirePayAmount;
	}
	
}//Class: PaymentDTO

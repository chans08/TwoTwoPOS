package com.twotwo.salesRegister;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.twotwo.home.DBUtil;

public class SalesRegisterDAO {
	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public SalesRegisterDAO() {
		DBUtil util = new DBUtil();
		conn = util.connect();
	}
	
	//카테고리 페이지 관련 메소드-----------------------------------------------------------------------------------------------
	
	/**
	 * categoryItem 테이블에 categorySeq가 인자값을 가진 개체가 있는지 확인해서 수정할지 더할지 결정할 수 있게 하는 메소드
	 * @param categorySeq
	 * @return
	 */
	public int existCategorySeq(String categorySeq) {
		try {
			String sql = "select count(*) as cnt from tblitemCategory where categorySeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, categorySeq);
			
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.existCategorySeq : " + e.toString());
		}
		return 0;
	}

	public int addItemCategory(ItemCategoryDTO itemCategoryDTO) {
		try {
			String sql = "insert into tblitemCategory (categorySeq, categoryName) values (?, ?)";
			stat = conn.prepareStatement(sql);
			stat.setString(1, itemCategoryDTO.getCategorySeq());
			stat.setString(2, itemCategoryDTO.getCategoryName());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.addItemCategory : " + e.toString());
		}
		return 0;
	}
	
	/**
	 * 카테고리 수정
	 * @param dto
	 * @return
	 */
	public int editItemCategory(ItemCategoryDTO dto) {
		try {
			String sql = "update tblitemCategory set categoryName = ? where categoryseq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getCategoryName());
			stat.setString(2, dto.getCategorySeq());
			
			return stat.executeUpdate();
		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.addItemCategory : " + e.toString());
		}
		return 0;
	}
	
	/**
	 * 현재 페이지의 카테고리리스트를 가져오는 메소드
	 * @param firstkeySeq
	 * @return
	 */
	public ArrayList<ItemCategoryDTO> itemCategorylist(int firstkeySeq) {
		try {
			String sql = "select * from tblitemCategory where categorySeq between ? and ? order by categoryseq";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, firstkeySeq);
			stat.setInt(2, firstkeySeq + 9);
			rs = stat.executeQuery();
			
			ArrayList<ItemCategoryDTO> list = new ArrayList<ItemCategoryDTO>();
			
			while (rs.next()) {
				ItemCategoryDTO dto = new ItemCategoryDTO();
				dto.setCategorySeq(rs.getString("categorySeq"));
				dto.setCategoryName(rs.getString("categoryName"));
				
				list.add(dto);
			}
			return list;

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.itemCategorylist : " + e.toString());
		}
		return null;
	}

	/**
	 * 카테고리의 다음 페이지가 존재하는지 체크하는 메소드
	 * @param firstkeySeq
	 * @return 다음페이지 존재(x) : 0 또는 다음페이지 존재 : 1
	 */
	public int existNextPage(int firstkeySeq) {
		try {
			String sql = "select count(*) as cnt from tblitemCategory where categorySeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, firstkeySeq + 10);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt");
			}
			
		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.existNextPage : " + e.toString());
		}
		return 0;
	}
	

	/** 
	 * 다음 카테고리 페이지 생성 메소드
	 * @return
	 */
	public int addCategoryPage(int nextkeySeq) {
		try {
			
			int result = 1;
			
			for (int i=nextkeySeq; i<=nextkeySeq+9; i++) {
				String sql = "insert into tblitemcategory (categorySeq, categoryName) values (?, null)";
				stat = conn.prepareStatement(sql);
				stat.setInt(1, i);
				
				result *= stat.executeUpdate();				
			}
			
			
			for (int j=1; j<=34; j++) {
				String sql = "insert into tblitem (itemSeq, menuSeq, itemName, itemPrice, categorySeq) values (itemseq.nextval, " + j + ", null, null, " + nextkeySeq + ")";
				stat = conn.prepareStatement(sql);
				result *= stat.executeUpdate();
			}
			
			return result;
		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.addCategoryPage : " + e.toString());
		}
		return 0;
	}

	public int getMaxCategoryPage() {
		try {
			String sql = "select max(categorySeq) as maxSeq from tblitemCategory";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				int maxPage = rs.getInt("maxSeq");
				if (maxPage % 10 == 0) {
					maxPage = maxPage / 10;
				} else {
					maxPage = maxPage / 10 + 1;
				}
				
				return maxPage;
			}

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.getMaxCategoryPage : " + e.toString());
		}
		return 0;
	}
	
	//메뉴 페이지 관련 메소드-----------------------------------------------------------------------------------------------
	/**
	 * 메뉴의 다음 페이지가 존재하는지 체크하는 메소드
	 * @param mfirstkeySeq
	 * @param categorySeq 
	 * @return
	 */
	public int existMnextPage(int mfirstkeySeq, String categorySeq) {
		try {
			String sql = "select count(*) as cnt from tblitem where menuSeq = ? and categorySeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, mfirstkeySeq + 34);
			stat.setString(2, categorySeq);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt");
			}
			
		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.existMnextPage : " + e.toString());
		}
		return 0;
	}

	/**
	 * 다음 메뉴 페이지 생성 메소드
	 * @param mnextkeySeq
	 * @param categorySeq 
	 * @return
	 */
	public int addMenuPage(int mnextkeySeq, String categorySeq) {
		try {
			
			int result = 1;
			
			for (int i=mnextkeySeq; i<=mnextkeySeq+33; i++) {
				String sql = "insert into tblitem (itemSeq, menuSeq, itemName, itemPrice, categorySeq) values (itemseq.nextval, ?, null, null, ?)";
				stat = conn.prepareStatement(sql);
				stat.setInt(1, i);
				stat.setString(2, categorySeq);
				
				result *= stat.executeUpdate();
			}
			
			return result;
		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.addMenuPage : " + e.toString());
		}
		return 0;
	}
	
	
	/**
	 * 현재 페이지의 메뉴리스트를 가져오는 메소드
	 * @param mfirstkeySeq
	 * @param firstkeySeq 
	 * @return
	 */
	public ArrayList<ItemDTO> itemlist(int mfirstkeySeq, String categorySeq) {
		try {
			String sql = "select * from tblitem where menuSeq between ? and ? and categorySeq = ? order by menuSeq";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, mfirstkeySeq);
			stat.setInt(2, mfirstkeySeq + 33);
			stat.setString(3, categorySeq);
			rs = stat.executeQuery();
			
			ArrayList<ItemDTO> list = new ArrayList<ItemDTO>();
			
			while (rs.next()) {
				ItemDTO dto = new ItemDTO();
				dto.setMenuSeq(rs.getString("menuSeq"));
				dto.setItemName(rs.getString("itemName"));
				dto.setItemPrice(rs.getInt("itemPrice"));
				dto.setCategorySeq(rs.getString("categorySeq"));
				
				list.add(dto);
			}
			return list;

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.itemlist : " + e.toString());
		}
		return null;
	}
	
	/**
	 * 최대 메뉴페이지 가져오는 메소드
	 * @param categorySeq 
	 * @return
	 */
	public int getMaxMenuPage(String categorySeq) {
		try {
			String sql = "select max(menuSeq) as maxSeq from tblitem where categorySeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, categorySeq);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				int maxPage = rs.getInt("maxSeq");
				
				if (maxPage % 34 == 0) {
					maxPage = maxPage / 34;
				} else {
					maxPage = maxPage / 34 + 1;
				}
				
				return maxPage;
			}

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.getMaxItemPage : " + e.toString());
		}
		return 0;
	}

	public String getCategoryName(ItemDTO dto) {
		
		try {
			String sql = "select * from tblitemCategory where categorySeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getCategorySeq());

			rs = stat.executeQuery();

			if (rs.next()) {
				
				return rs.getString("categoryname");
			}

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.get : " + e.toString());
		}
		return null;
	}
	
	/**
	 * 메뉴 등록 메소드
	 * @param itemDTO
	 * @return
	 */
	public int editItem(ItemDTO itemDTO) {
		try {
			String sql = "update tblitem set itemName = ?, itemPrice = ? where categorySeq = ? and menuSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, itemDTO.getItemName());
			stat.setInt(2, itemDTO.getItemPrice());
			stat.setString(3, itemDTO.getCategorySeq());
			stat.setString(4, itemDTO.getMenuSeq());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.editItem : " + e.toString());
		}
		return 0;
	}
	
	/**
	 * 등록할 메뉴 위치에 이미 메뉴가 존재하는지 확인하는 메소드
	 * @param categorySeq
	 * @param menuSeq
	 * @return
	 */
	public int existMenuSeq(String categorySeq, String menuSeq) {
		try {
			String sql = "select count(*) as cnt from tblitem where categorySeq = ? and menuSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, categorySeq);
			stat.setString(2, menuSeq);
			
			rs = stat.executeQuery();
			if (rs.next()) {
				return rs.getInt("cnt");
			}
			

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.existMenuSeq : " + e.toString());
		}
		return 0;
	}
	
	/**
	 * 수정할 메뉴 위치에 있는 상품 정보 가져오는 메소드
	 * @param categorySeq
	 * @param menuSeq
	 * @return
	 */
	public ItemDTO getItem(String categorySeq, String menuSeq) {
		try {
			String sql = "select * from vwItem where categorySeq = ? and menuSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, categorySeq);
			stat.setString(2, menuSeq);
			
			rs = stat.executeQuery();
			
			if (rs.next()) {
				ItemDTO dto = new ItemDTO();
				dto.setCategorySeq(categorySeq);
				dto.setCategoryName(rs.getString("categoryname"));
				dto.setMenuSeq(rs.getString("menuseq"));
				dto.setItemName(rs.getString("itemname"));
				dto.setItemPrice(rs.getInt("itemprice"));
				
				return dto;
			}

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.getItem : " + e.toString());
		}
		return null;
	}
	
	/**
	 * 새로이 메뉴를 등록하는 메소드
	 * @param itemDTO
	 * @return
	 */
	public int addItem(ItemDTO itemDTO) {
		try {
			String sql = "insert into tblitem (itemSeq, menuSeq, itemName, itemPrice, categorySeq) values (itemSeq.nextval, ?, ?, ?, ?)";
			stat = conn.prepareStatement(sql);
			stat.setString(1, itemDTO.getMenuSeq());
			stat.setString(2, itemDTO.getItemName());
			stat.setInt(3, itemDTO.getItemPrice());
			stat.setString(4, itemDTO.getCategorySeq());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.addItem : " + e.toString());
		}
		return 0;
	}

	//salelist에 등록되는 상품 정보를 dto에 담아 반환하는 메소드
	public PaymentDTO getSaleItem(ItemDTO dto) {
		try {
			String sql = "select * from vwItem where categorySeq = ? and menuSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getCategorySeq());
			stat.setString(2, dto.getMenuSeq());
			rs = stat.executeQuery();
			
			if (rs.next()) {
				PaymentDTO saleitemdto = new PaymentDTO();
				dto.setItemSeq(rs.getString("itemseq"));
				dto.setItemName(rs.getString("itemname"));
				
				return saleitemdto;
			}
			
			

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.getSaleItem : " + e.toString());
		}
		return null;
	}

	/**
	 * 분류번호, 메뉴번호 -> 상품명, 상품번호, 상품가격을 가져오는 메소드
	 * @param dto
	 * @return
	 */
	public ItemDTO getItemInfo(ItemDTO dto) {
		try {
			String sql = "select * from vwItem where categorySeq = ? and menuSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getCategorySeq());
			stat.setString(2, dto.getMenuSeq());
			rs = stat.executeQuery();
			
			if (rs.next()) {
				PaymentDTO saleitemdto = new PaymentDTO();
				
				dto.setItemSeq(rs.getString("itemseq"));
				dto.setItemName(rs.getString("itemname"));
				dto.setItemPrice(rs.getInt("itemPrice"));
				
				return dto;
			}
			

		} catch (Exception e) {
			System.out.println("SalesRegisterDAO.getItemInfo : " + e.toString());
		}
		return null;
	}
	
	


	
	
	

	
	
}

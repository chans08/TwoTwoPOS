package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginok.do")
public class LoginOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// LoginOk.java
		// 1. 데이터 가져오기
		// 2. DB 작업 > DAO 위임(select where)
		// 3. 결과 반환
		// 3.1 인증 성공 > 인증 티켓 발급
		// 3.2 인증 실패 > x
		// 4. JSP 호출

		// 서블릿에서 session 객체 얻어오기

		HttpSession session = req.getSession();

		req.setCharacterEncoding("UTF-8");

		String inputid = req.getParameter("id");
		String inputpw = req.getParameter("pw");
		String loginmaintain = req.getParameter("maintain");
		//System.out.println(loginmaintain);

		VwEmployee dto = new VwEmployee();
		dto.setUserId(inputid);
		dto.setUserPw(inputpw);

		EmployeeDAO dao = new EmployeeDAO();
		
		
			VwEmployee result = new VwEmployee();

		
					int loginCheck = dao.loginCheck(dto);
					
					result = dao.login(dto); // not null | null
					
		
		
		if (result != null) {
			// 로그인 성공 > 인증 티켓 발급
			session.setAttribute("id", result.getUserId()); // 인증 티켓("auth")
			session.setAttribute("pw", result.getUserPw());
			session.setAttribute("name", result.getName());
			session.setAttribute("position", result.getPosition());
			session.setAttribute("blNumber", result.getBlNumber());
			session.setAttribute("birthdate", result.getBirthDate());
			session.setAttribute("gender", result.getGender());
			session.setAttribute("email", result.getEmail());
			session.setAttribute("tel", result.getTel());
			session.setAttribute("ibsadate", result.getIbsadate());
			session.setAttribute("pwhintq", result.getPwHintQ());
			session.setAttribute("pwhinta", result.getPwHintA());
			session.setAttribute("pic", result.getPic());
			session.setAttribute("cafename", result.getCafename());

			 /*
             *  [   세션 추가되는 부분  ]
             */
			
            // 1. 로그인이 성공하면, 그 다음으로 로그인 폼에서 쿠키가 체크된 상태로 로그인 요청이 왔는지를 확인한다.
            if (loginmaintain != null && loginmaintain.equals("on")){ // dto 클래스 안에 useCookie 항목에 폼에서 넘어온 쿠키사용 여부(true/false)가 들어있을 것임
                //null은 없는 값이라.equals를 붙일 수 없다.
          
            	// 쿠키 사용한다는게 체크되어 있으면...
                // 쿠키를 생성하고 현재 로그인되어 있을 때 생성되었던 세션의 id를 쿠키에 저장한다.
            	Cookie id = new Cookie("id", result.getUserId());
            	Cookie pw = new Cookie("pw", result.getUserPw());
            	Cookie name = new Cookie("name", result.getName());
            	Cookie position = new Cookie("position", result.getPosition());
            	Cookie pic = new Cookie("pic", result.getPic());
            	Cookie cafename = new Cookie("cafename", result.getCafename());
            	
            	//System.out.println(result.getCafename());
    			
            	id.setMaxAge(60 * 60 * 24 * 7);		// 단위는 (초)임으로 7일정도로 유효시간을 설정해 준다.
    			id.setPath("/");								// 쿠키를 찾을 경로를 컨텍스트 경로로 변경해 주고...
    			pw.setMaxAge(60 * 60 * 24 * 7);
    			pw.setPath("/");
    			name.setMaxAge(60 * 60 * 24 * 7);
    			name.setPath("/");
    			position.setMaxAge(60 * 60 * 24 * 7);
    			position.setPath("/");
    			pic.setMaxAge(60 * 60 * 24 * 7);
    			pic.setPath("/");
    			cafename.setMaxAge(60 * 60 * 24 * 7);
    			cafename.setPath("/");

    			 // 쿠키를 적용해 준다.
    			resp.addCookie(id);
    			resp.addCookie(pw);
    			resp.addCookie(name);
    			resp.addCookie(position);
    			resp.addCookie(pic);
    			resp.addCookie(cafename);
            }
            
		}
		
		req.setAttribute("loginCheck", loginCheck);
		req.setAttribute("inputid", inputid);
		req.setAttribute("inputpw", inputpw);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/loginok.jsp");
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
}

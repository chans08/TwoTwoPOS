package com.twotwo.additional.announcement;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/additional/announcement/addok.do")
public class AddOk extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("test");
		HttpSession session = req.getSession();
		req.setCharacterEncoding("UTF-8");
		
		String employeeboardOption = req.getParameter("employeeboardOption");
		String subject = req.getParameter("subject");
		String writer = req.getParameter("writer");
		String content = req.getParameter("content");
		
		BoardDAO dao = new BoardDAO();
		BoardDTO dto = new BoardDTO();
		
		dto.setEmployeeboardOption(employeeboardOption);
		dto.setSubject(subject);
		dto.setWriter(session.getAttribute("id").toString());
		dto.setContent(content);
		
		//???
		int result = dao.add(dto);
		
		//3. addok.jsp
		if (result == 1) {
			resp.sendRedirect("/TwoTwoPOS/additional/announcement/announcement.do");
		} else {
			resp.getWriter().print("<script>alert('failed');history.back();</script>");
			resp.getWriter().close();
		}
	}
}


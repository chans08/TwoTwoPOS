package com.twotwo.inventory;

public class InventoryDTO {

	private String inventorySeq;
	private String inventoryName;
	private int inventoryCount;
	private String operateDate;
	private int inventoryType;
	
	
	public String getInventorySeq() {
		return inventorySeq;
	}
	public void setInventorySeq(String inventorySeq) {
		this.inventorySeq = inventorySeq;
	}
	public String getInventoryName() {
		return inventoryName;
	}
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}
	public int getInventoryCount() {
		return inventoryCount;
	}
	public void setInventoryCount(int inventoryCount) {
		this.inventoryCount = inventoryCount;
	}
	public String getOperateDate() {
		return operateDate;
	}
	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}
	public int getInventoryType() {
		return inventoryType;
	}
	public void setInventoryType(int inventoryType) {
		this.inventoryType = inventoryType;
	}
	
	
	

	
	
}

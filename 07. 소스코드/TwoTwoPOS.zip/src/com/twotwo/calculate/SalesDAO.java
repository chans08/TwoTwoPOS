package com.twotwo.calculate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.twotwo.calculate.DBUtil;

public class SalesDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public SalesDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}//salesDAO

//------------------------------------------------------------------
	
	public ArrayList<SalesDTO> calculate() {
		
		try {
			
			String sql = "SELECT * FROM tblTest";
			
			stat = conn.prepareStatement(sql);	
			rs = stat.executeQuery();
			
			ArrayList<SalesDTO> list = new ArrayList<SalesDTO>();
			
			while(rs.next()) {
				
				SalesDTO dto = new SalesDTO();
				dto.setTotalSales(rs.getString("totalSales"));
				dto.setDiscountSales(rs.getString("discountSales"));
				dto.setRawSales(rs.getString("rawSales"));
				dto.setTax(rs.getString("tax"));
				dto.setRefundSales(rs.getString("refundSales"));				
				list.add(dto);
				
			}
			
			return list;
			
		} catch (Exception e) {
			System.out.println("SalesDAO.calculate : " + e.toString());
		}
		
		return null;
		
	}//method: calculate
	
	
	
}//class

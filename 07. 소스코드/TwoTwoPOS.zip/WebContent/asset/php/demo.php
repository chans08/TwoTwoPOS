<?php
	header("Content-Type: text/html; charset=utf-8");

	if ($_POST) {

		echo '<div class="success-message unit"><i class="fa fa-check"></i>Your message has been sent</div>';

	}
?>
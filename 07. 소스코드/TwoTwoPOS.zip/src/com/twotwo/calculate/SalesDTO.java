package com.twotwo.calculate;

public class SalesDTO {

	private String totalSales;
	private String discountSales;
	private String rawSales;
	private String tax;
	private String refundSales;
	
	public String getTotalSales() {
		return totalSales;
	}
	public void setTotalSales(String totalSales) {
		this.totalSales = totalSales;
	}
	public String getDiscountSales() {
		return discountSales;
	}
	public void setDiscountSales(String discountSales) {
		this.discountSales = discountSales;
	}
	public String getRawSales() {
		return rawSales;
	}
	public void setRawSales(String rawSales) {
		this.rawSales = rawSales;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	public String getRefundSales() {
		return refundSales;
	}
	public void setRefundSales(String refundSales) {
		this.refundSales = refundSales;
	}
	
	
}

package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login/pwchangeok.do")
public class PwchangeOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//PwchangeOk.java
		req.setCharacterEncoding("UTF-8");
		//1. 데이터 가져오기
		String name = req.getParameter("name");
		String pw = req.getParameter("pw");
		
		VwEmployee dto = new VwEmployee();
		
		dto.setName(name);
		dto.setUserPw(pw);
		
		// 2. DB 작업 > DAO 위임(select where)
		EmployeeDAO dao = new EmployeeDAO();
		
		int result = dao.pwCheck(dto);
		
		req.setAttribute("result", result);
		req.setAttribute("name", name);
		// 3. JSP 호출

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/pwchangeok.jsp");
		dispatcher.forward(req, resp);
	}
}

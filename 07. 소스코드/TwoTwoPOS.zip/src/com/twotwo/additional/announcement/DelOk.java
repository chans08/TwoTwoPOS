package com.twotwo.additional.announcement;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/additional/announcement/delok.do")
public class DelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		int employeeboardSeq = Integer.parseInt(req.getParameter("employeeboardSeq"));
		
		BoardDAO dao = new BoardDAO();
		
		int result = -1;
		
		
		if (dao.isOwner(employeeboardSeq, session.getAttribute("id").toString())) {
			result = dao.del(employeeboardSeq);
		}else {
			result = 2;
		}
		
		if (result == 1) {
			resp.sendRedirect("/TwoTwoPOS/additional/announcement/announcement.do"); //목록
		} else {
			resp.getWriter().print("<script> alert('Failed'); history.back(); </script>");
			resp.getWriter().close();
		}
	}
}


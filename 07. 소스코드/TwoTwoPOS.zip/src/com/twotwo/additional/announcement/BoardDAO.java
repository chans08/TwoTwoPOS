package com.twotwo.additional.announcement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.twotwo.home.DBUtil;

public class BoardDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	public BoardDAO() {
		try {
			
			//this.conn = DBUtil.getConnection();
			DBUtil util = new DBUtil();
			conn = util.connect();
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}

//-----------------------------------------------------------------------------------------------------------
	
	public int add(BoardDTO dto) {

		try {

			String sql = "insert into tblEmployeeBoard "
					+ "(employeeboardSeq, writer, employeeboardOption, subject, content, registerDate, readCount) "
						+ "values (employeeBoardseq.nextval, ?, ?, ?, ?, sysdate, 0)";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getWriter());
			stat.setString(2, dto.getEmployeeboardOption());
			stat.setString(3, dto.getSubject());
			stat.setString(4, dto.getContent());

//			System.out.println(dto.getWriter());
//			System.out.println(dto.getEmployeeboardOption());
//			System.out.println(dto.getSubject());
//			System.out.println(dto.getContent());

			return stat.executeUpdate();// add

		} catch (Exception e) {
			System.out.println("BoardDAO.add : " + e.toString());
		}
		return 0;
	}

	public void close() {
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println("BoardDAO.close : " + e.toString());
		}
	}

//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<BoardDTO> list() {

		try {
			String sql = "select * from tblEmployeeBoard";

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

			while (rs.next()) {
				
				BoardDTO dto = new BoardDTO();
				dto.setEmployeeboardSeq(rs.getInt("employeeboardSeq"));
				dto.setWriter(rs.getString("writer"));
				dto.setEmployeeboardOption(rs.getString("employeeboardOption"));
				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("content"));
				dto.setRegisterDate(rs.getString("registerDate"));
				dto.setReadCount(rs.getInt("readCount"));

				list.add(dto);
			}

			return list;

		} catch (Exception e) {
			System.out.println("BoardDAO.list : " + e.toString());
		}

		return null;

	}

//-----------------------------------------------------------------------------------------------------------
	
	public void addReadCount(String seq) {
		try {
			String sql = "update tblEmployeeBoard set readcount = readcount + 1 where employeeboardSeq = ?";

			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);

			stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("BoardDAO.addReadCount : " + e.toString());
		}

	}

//-----------------------------------------------------------------------------------------------------------

	public BoardDTO get(String employeeboardSeq) {

		try {

			// String sql = "select b.*, (select writer from tblEmployeeBoard where id = b.id) as writer "
			// + "from tblEmployeeBoard b where employeeboardSeq = ?";

			String sql = "SELECT * FROM tblEmployeeBoard WHERE employeeboardSeq = ?";

			stat = conn.prepareStatement(sql);
			stat.setString(1, employeeboardSeq);

			rs = stat.executeQuery();

			if (rs.next()) {

				BoardDTO dto = new BoardDTO();

				dto.setEmployeeboardSeq(rs.getInt("employeeboardSeq"));
				dto.setWriter(rs.getString("writer"));
				dto.setEmployeeboardOption(rs.getString("employeeboardoption"));
				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("content"));
				dto.setRegisterDate(rs.getString("registerDate"));
				dto.setReadCount(rs.getInt("readCount"));

				return dto;

			}

		} catch (Exception e) {
			System.out.println("BoardDAO.get : " + e.toString());
		}

		return null;

	}// method: get
	
//-----------------------------------------------------------------------------------------------------------

	public boolean isOwner(int employeeboardSeq, String writer) {

		try {
			String sql = "select count(*) as cnt from tblEmployeeBoard where employeeboardSeq = ? and writer = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setInt(1, employeeboardSeq);
			stat.setString(2, writer);
			
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt") == 1 ? true : false;
			}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		
		return false;
	}
	
//-----------------------------------------------------------------------------------------------------------

	public int del(int employeeboardSeq) {
		
		try {
			String sql = "delete from tblEmployeeBoard where employeeboardSeq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setInt(1, employeeboardSeq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("BoardDAO.del : " + e.toString());
		}
		
		return 0;
	}

//-----------------------------------------------------------------------------------------------------------	
	
	public int edit(BoardDTO dto) {
		
		try {

			String sql = "update tblEmployeeBoard set employeeboardOption= ?, subject = ?, content = ?"
							+ " where employeeboardSeq = ?";

			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getEmployeeboardOption());
			stat.setString(2, dto.getSubject());
			stat.setString(3, dto.getContent());
			stat.setInt(4, dto.getEmployeeboardSeq());
			
			
			return stat.executeUpdate();
			

		} catch (Exception e) {
			System.out.println("BoardDAO.edit : " + e.toString());
		}
		
		return 0;
	}

//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<BoardDTO> list(HashMap<String, String> map) {
		
		try {
			
			String temp = "";
			
			if (map.containsKey("column")) {
				temp = String.format("and %s like '%%%s%%'", map.get("column"), map.get("word"));
			}
			
			
			
			//select * from (select a.*, rownum as rnum from (select num, name, city, buseo, jikwi from tblInsa order by num asc) a) where rnum between %s and %s %s
			
			//select employeeboardSeq, writer, employeeboardOption, subject, Content, registerDate , readCount from tblEmployeeBoard  %s order by registerDate asc
			
			String sql = String.format("select * from(select a.*, rownum as rnum from (select employeeboardSeq, writer, employeeboardOption, subject, Content, registerDate , readCount from tblEmployeeBoard order by registerDate asc) a) where rnum between %s and %s %s", map.get("begin"), map.get("end"), temp);
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
			
			while (rs.next()) {
				BoardDTO dto = new BoardDTO();
				
				dto.setEmployeeboardSeq(rs.getInt("employeeboardSeq"));
				dto.setWriter(rs.getString("writer"));
				dto.setEmployeeboardOption(rs.getString("employeeboardOption"));
				dto.setSubject(rs.getString("subject"));
				dto.setContent(rs.getString("Content"));
				dto.setRegisterDate(rs.getString("registerDate"));
				dto.setReadCount(rs.getInt("readCount"));
				list.add(dto);
			}
			
			return list;
			
		} catch (Exception e) {
			
			System.out.println("BoardDAO.list : " + e.toString());
		
		}
		
		return null;
		
	}

	public int getTotalCount() {
		
		try {
			
			String sql = "select count(*) as cnt from tblEmployeeBoard";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt");
			}
			
			
		} catch (Exception e) {
			
			System.out.println("BoardDAO.getTotalCount : " + e.toString());
		}
		
		return 0;
	}
	
	
}// Class: BoardDAO

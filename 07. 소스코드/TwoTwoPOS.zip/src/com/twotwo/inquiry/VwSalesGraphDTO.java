package com.twotwo.inquiry;

public class VwSalesGraphDTO {

	private String ageLevel;
	private String gender;
	private String salesAmount;
	
	public String getAgeLevel() {
		return ageLevel;
	}
	public void setAgeLevel(String ageLevel) {
		this.ageLevel = ageLevel;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(String salesAmount) {
		this.salesAmount = salesAmount;
	}
	
}//Class: VwSalesGraph

package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login/newpw.do")
public class Newpw extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//Newpw.java
		req.setCharacterEncoding("UTF-8");
		//1. 데이터 가져오기
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		
		System.out.println(id);
		System.out.println(pw);
		
		VwEmployee dto = new VwEmployee();
		
		dto.setUserId(id);
		dto.setUserPw(pw);
		
		// 2. DB 작업 > DAO 위임(update)
		EmployeeDAO dao = new EmployeeDAO();
		
		int result = dao.pwChange(dto);
		
		System.out.println(result);
		
		req.setAttribute("result", result);
		
		// 3. JSP 호출

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/newpw.jsp");
		dispatcher.forward(req, resp);
	}
}
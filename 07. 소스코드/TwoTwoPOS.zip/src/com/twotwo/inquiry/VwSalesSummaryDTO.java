package com.twotwo.inquiry;

public class VwSalesSummaryDTO {

	private String entirePayAmount;
	private String refundAmount;
	private String discountAmount;
	private String tax;
	private String sellCount;
	private String refundCount;
	private String cashSell;
	private String cashSellCount;
	private String cardSell;
	private String cardSellCount;
	private String etcSell;
	private String etcSellCount;

	public String getEntirePayAmount() {
		return entirePayAmount;
	}
	public void setEntirePayAmount(String entirePayAmount) {
		this.entirePayAmount = entirePayAmount;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getDiscountAmount() {
		return discountAmount;
	}
	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
	public String getSellCount() {
		return sellCount;
	}
	public void setSellCount(String sellCount) {
		this.sellCount = sellCount;
	}
	public String getRefundCount() {
		return refundCount;
	}
	public void setRefundCount(String refundCount) {
		this.refundCount = refundCount;
	}
	public String getCashSell() {
		return cashSell;
	}
	public void setCashSell(String cashSell) {
		this.cashSell = cashSell;
	}
	public String getCashSellCount() {
		return cashSellCount;
	}
	public void setCashSellCount(String cashSellCount) {
		this.cashSellCount = cashSellCount;
	}
	public String getCardSell() {
		return cardSell;
	}
	public void setCardSell(String cardSell) {
		this.cardSell = cardSell;
	}
	public String getCardSellCount() {
		return cardSellCount;
	}
	public void setCardSellCount(String cardSellCount) {
		this.cardSellCount = cardSellCount;
	}
	public String getEtcSell() {
		return etcSell;
	}
	public void setEtcSell(String etcSell) {
		this.etcSell = etcSell;
	}
	public String getEtcSellCount() {
		return etcSellCount;
	}
	public void setEtcSellCount(String etcSellCount) {
		this.etcSellCount = etcSellCount;
	}
	 
}//Class: PaymentDTO

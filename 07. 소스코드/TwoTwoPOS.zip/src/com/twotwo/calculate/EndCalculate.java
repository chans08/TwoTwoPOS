package com.twotwo.calculate;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/calculate/endCalculate.do")
public class EndCalculate extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//{primary type name}
		String currentMoney = req.getParameter("currentMoney");
		//System.out.println("currentMoney : " + currentMoney);
		
		SalesDAO dao = new SalesDAO();
		
		ArrayList<SalesDTO> list = dao.calculate();
		
		//System.out.println(list);
		
		req.setAttribute("list", list);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/calculate/endCalculate.jsp");
		dispatcher.forward(req, resp);
	}

}
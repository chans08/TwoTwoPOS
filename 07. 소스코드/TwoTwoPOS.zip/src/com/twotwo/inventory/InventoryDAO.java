package com.twotwo.inventory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.twotwo.home.DBUtil;

public class InventoryDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	public InventoryDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}

	public ArrayList<ArrayList<InventoryDTO>> getInvenList(HashMap<String, String> map) {

		try {

			String sql = "select distinct inventoryName from tblInventory";

			stat = conn.prepareStatement(sql);

			rs = stat.executeQuery();

			ArrayList<ArrayList<InventoryDTO>> list = new ArrayList<ArrayList<InventoryDTO>>();

			while (rs.next()) {

				String inventoryName = rs.getString("inventoryName");

				String sql2 = "select * from tblinventory where inventoryName = ? and operatedate between ? and ? order by operateDate asc";

				PreparedStatement stat2 = conn.prepareStatement(sql2);

				stat2.setString(1, inventoryName);
				stat2.setString(2, map.get("begin"));
				stat2.setString(3, map.get("end"));

				ResultSet rs2 = stat2.executeQuery();

				ArrayList<InventoryDTO> sublist = new ArrayList<InventoryDTO>();

				while (rs2.next()) {
					InventoryDTO dto = new InventoryDTO();
					/*
					 * dto.setSeq(rs2.getString("inventorySeq"));
					 * dto.setName(rs2.getString("inventoryName"));
					 * dto.setCount(rs2.getInt("inventoryCount"));
					 * dto.setDate_inven(rs2.getString("operateDate"));
					 */

					dto.setInventorySeq(rs2.getString("inventorySeq"));
					dto.setInventoryName(rs2.getString("inventoryName"));
					dto.setInventoryCount(rs2.getInt("inventoryCount"));
					dto.setOperateDate(rs2.getString("operateDate"));
					dto.setInventoryType(rs2.getInt("inventoryType"));

					sublist.add(dto);
				}

				list.add(sublist);

				rs2.close();

			}

			rs.close();

			return list;

		} catch (Exception e) {
			System.out.println("InventoryDAO.getInvenList : " + e.toString());
		}

		return null;
	}

}

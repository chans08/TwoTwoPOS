package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login/delemployeeok.do")
public class DelEmployeeOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//PwsearchOk.java
		// 1. 데이터 가져오기
		
		req.setCharacterEncoding("UTF-8");
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		String blnumber = req.getParameter("blnumber");
		
		VwEmployee dto = new VwEmployee();
		
		dto.setUserId(id);
		dto.setUserPw(pw);
		dto.setBlNumber(blnumber);
		
		// 2. DB 작업 > DAO 위임(select where)
		EmployeeDAO dao = new EmployeeDAO();
		
		int result = dao.delCheck(dto);
		System.out.println(result);
		int delresult = 0;
		if(result == 1) { //인증ok
			
			delresult = dao.delemployee(dto);
			System.out.println(delresult);
		}
		//VwEmployee userpw = dao.pwSearch(dto);
		
		if(delresult == 1) {
			HttpSession session = req.getSession();
			session.invalidate(); // 세션 전체를 날려버림
			
			// 로그인 유지 쿠키 삭제
			
			  Cookie[] cookies = req.getCookies(); 
			  if(cookies != null)
			  { 
				  for(Cookie cookie :cookies)
				  { 
						  	cookie.setMaxAge(0);
						  	cookie.setPath("/"); 
						  	resp.addCookie(cookie);
				  } 
				  
			  }
		}
	

		// 3. 결과 반환
		/*if(userpw != null) {
			req.setAttribute("userpw", userpw.getUserPw());
			req.setAttribute("id", userpw.getUserId());
			req.setAttribute("pwhintq", userpw.getPwHintQ());
			req.setAttribute("pwhinta", userpw.getPwHintA());
			
			} else if(userpw == null) {
				req.setAttribute("userpw", null);
			}*/
		
	
		req.setAttribute("result", result);
		req.setAttribute("delresult", delresult);
	
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/delemployeeok.jsp");
		dispatcher.forward(req, resp);
	}
}

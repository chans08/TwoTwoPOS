package com.twotwo.home;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/index.do")
public class Index extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HomeDAO dao = new HomeDAO();
		
		ArrayList<VwDailyWeatherDTO> weatherList = dao.dailyWeather();
		ArrayList<TodoListDTO> todoList = dao.todoList();
		
		req.setAttribute("weatherList", weatherList);
		req.setAttribute("todoList", todoList);

		//JSP 호출
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/index.jsp");
		dispatcher.forward(req, resp);

	}//method : doGet

}//Class : Index
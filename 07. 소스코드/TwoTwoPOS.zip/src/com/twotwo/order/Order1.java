package com.twotwo.order;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/order/order1.do")
public class Order1 extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//order1.java
		String orderName1 = req.getParameter("orderName1");
		String orderName2 = req.getParameter("orderName2");
		String orderName3 = req.getParameter("orderName3");
		String orderQuan1 = req.getParameter("orderQuan1");
		String orderQuan2 = req.getParameter("orderQuan2");
		String orderQuan3 = req.getParameter("orderQuan3");
		
		//System.out.println(orderName1);
		//System.out.println(orderQuan1);
		
		
		req.setAttribute("orderName1", orderName1);
		req.setAttribute("orderName2", orderName2);
		req.setAttribute("orderName3", orderName3);
		req.setAttribute("orderQuan1", orderQuan1);
		req.setAttribute("orderQuan2", orderQuan2);
		req.setAttribute("orderQuan3", orderQuan3);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/order/order1.jsp");
		dispatcher.forward(req, resp);

	}

}
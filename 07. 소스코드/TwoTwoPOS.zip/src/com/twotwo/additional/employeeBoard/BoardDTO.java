package com.twotwo.additional.employeeBoard;

public class BoardDTO {
	
	private int employeeboardSeq;
	private String writer;
	private String employeeboardOption;
	private String subject;
	private String content;
	private String registerDate;
	private int readCount;
	
	public String getWriter() {
		return writer;
	}
	public int getEmployeeboardSeq() {
		return employeeboardSeq;
	}
	public void setEmployeeboardSeq(int employeeboardSeq) {
		this.employeeboardSeq = employeeboardSeq;
	}
	public String content() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getEmployeeboardOption() {
		return employeeboardOption;
	}
	public void setEmployeeboardOption(String employeeboardOption) {
		this.employeeboardOption = employeeboardOption;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
	public int getReadCount() {
		return readCount;
	}
	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}
	
	
	
}

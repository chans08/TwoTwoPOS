package com.twotwo.inquiry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.twotwo.home.DBUtil;

public class InquiryDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public InquiryDAO() {	
		DBUtil util = new DBUtil();
		conn = util.connect();	
	}
	
//===========================================================================================================

	//매출요약
	
	public ArrayList<VwSalesSummaryDTO> salesAll(String operateDate) {
		
		try {

			String sql = "SELECT " + 
					"    SUM(entirepayamount) AS entirepayamount, " + 
					"    SUM(CASE WHEN refund = 1 THEN entirepayamount END) AS refundAmount, " + 
					"    SUM(discountAmount) AS discountAmount, " + 
					"    SUM(entirepayamount / 20) AS tax, " + 
					"    COUNT(paymentseq) AS sellCount, " + 
					"    COUNT(CASE WHEN refund = 1 THEN 1 END) AS refundCount, " + 
					"    SUM(cash) AS cashSell, " + 
					"    COUNT(CASE WHEN cash != 0 THEN 1 END) AS cashSellCount, " + 
					"    SUM(card) AS cardSell, " + 
					"    COUNT(CASE WHEN card != 0 THEN 1 END) AS cardSellCount, " + 
					"    0 AS etcSell, " + 
					"    0 AS etcSellCount " + 
					"	 FROM tblPayment " + 
					"    WHERE operateDate = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, operateDate);
			rs = stat.executeQuery();
			
			ArrayList<VwSalesSummaryDTO> summaryList = new ArrayList<VwSalesSummaryDTO>();
			
			while(rs.next()) {
				
				VwSalesSummaryDTO dto = new VwSalesSummaryDTO();
				dto.setEntirePayAmount(rs.getString("entirePayAmount"));
				dto.setRefundAmount(rs.getString("refundAmount"));
				dto.setDiscountAmount(rs.getString("discountAmount"));
				dto.setTax(rs.getString("tax"));
				dto.setSellCount(rs.getString("sellCount"));
				dto.setRefundCount(rs.getString("refundCount"));
				dto.setCashSell(rs.getString("cashSell"));
				dto.setCashSellCount(rs.getString("cashSellCount"));
				dto.setCardSell(rs.getString("cardSell"));
				dto.setCardSellCount(rs.getString("cardSellCount"));
				dto.setEtcSell(rs.getString("etcSell"));
				dto.setEtcSellCount(rs.getString("etcSellCount"));
				summaryList.add(dto);
				
			}
			
			return summaryList;

		} catch (Exception e) {
			System.out.println("InquiryDAO.salesAll : " + e.toString());
		}
		
		return null;
		
	}//method: salesAll

//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<VwSalesGraphDTO> salesGraph(String operateDate) {
		
		try {

			String sql = "SELECT " + 
					"    substr(TO_CHAR(sysdate, 'YYYY') - TO_CHAR(mem.birth, 'YYYY'), 1, 1) AS ageLevel, " + 
					"    (CASE " + 
					"        WHEN mem.gender = 0 THEN '0' " + 
					"        WHEN mem.gender = 1 THEN '1' " + 
					"    END) AS gender, " + 
					"    SUM(pay.payAmount) AS salesAmount " + 
					"FROM tblPayment pay " + 
					"    INNER JOIN tblMember mem " + 
					"        ON pay.memberSeq = mem.memberseq " + 
					"            WHERE pay.operateDate = ? " + 
					"                GROUP BY substr(TO_CHAR(sysdate, 'YYYY') - TO_CHAR(mem.birth, 'YYYY'), 1, 1), mem.gender " + 
					"                    ORDER BY ageLevel";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, operateDate);
			rs = stat.executeQuery();
			
			ArrayList<VwSalesGraphDTO> summaryGraph = new ArrayList<VwSalesGraphDTO>();
			
			while(rs.next()) {
				
				VwSalesGraphDTO dto = new VwSalesGraphDTO();
				dto.setAgeLevel(rs.getString("ageLevel"));
				dto.setGender(rs.getString("gender"));
				dto.setSalesAmount(rs.getString("salesAmount"));
				summaryGraph.add(dto);
					
			}
			
			return summaryGraph;

		} catch (Exception e) {
			System.out.println("InquiryDAO.salesGraph : " + e.toString());
		}
		
		return null;
		
	}//method: salesGraph

//===========================================================================================================
	
	//판매내역조회
	
	public ArrayList<VwSalesInquiryDTO> salesInquiry(String operateDate1, String operateDate2) {
		
		try {

			String sql = "SELECT " + 
					"ROWNUM AS no, " + 
					"a.operateDate AS operateDate, " + 
					"a.orderNumber AS orderNumber, " + 
					"1 AS posNum, " + 
					"a.entirePayAmount AS entirePayAmount " + 
					"    FROM (SELECT paymentSeq, operateDate, orderNumber, entirePayAmount " + 
					"        FROM tblPayment WHERE operateDate BETWEEN ? AND ?) a";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, operateDate1);
			stat.setString(2, operateDate2);
			rs = stat.executeQuery();	
			
			ArrayList<VwSalesInquiryDTO> inquiryList = new ArrayList<VwSalesInquiryDTO>();
			
			while(rs.next()) {
				
				VwSalesInquiryDTO dto = new VwSalesInquiryDTO();
				dto.setNo(rs.getString("no"));
				dto.setOperateDate(rs.getString("operateDate"));
				dto.setOrderNumber(rs.getString("orderNumber"));
				dto.setPosNum(rs.getString("posNum"));
				dto.setEntirePayAmount(rs.getString("entirePayAmount"));
				inquiryList.add(dto);
				
			}
			
			return inquiryList;

		} catch (Exception e) {
			System.out.println("InquiryDAO.salesInquiry : " + e.toString());
		}
		
		return null;
		
	}//method: salesInquiry

//-----------------------------------------------------------------------------------------------------------
	
	public ArrayList<VwSalesReceiptDTO> salesReceipt(String orderNumber, String receiptDate) {
		
		try {

			String sql = "SELECT " + 
					"    pay.orderNumber AS orderNumber, " + 
					"    pay.operatedate AS operateDate, " + 
					"    to_char(operateDate, 'day') AS operateDay, " + 
					"    item.itemname AS itemName, " + 
					"    item.itemprice AS itemPrice, " + 
					"    pay.orderamount AS orderAmount, " + 
					"    1 AS posNum " + 
					"FROM tblpayment pay " + 
					"    INNER JOIN tblItem item " + 
					"        ON pay.itemseq = item.itemseq " + 
					"        WHERE pay.orderNumber = ? AND pay.operateDate = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, orderNumber);
			stat.setString(2, receiptDate);
			rs = stat.executeQuery();	
			
			ArrayList<VwSalesReceiptDTO> inquiryReceipt = new ArrayList<VwSalesReceiptDTO>();
			
			while(rs.next()) {
				
				VwSalesReceiptDTO dto = new VwSalesReceiptDTO();
				dto.setOrderNumber(rs.getString("orderNumber"));
				dto.setOperateDate(rs.getString("operateDate"));
				dto.setOperateDay(rs.getString("operateDay"));
				dto.setItemName(rs.getString("itemName"));
				dto.setItemPrice(rs.getString("itemPrice"));
				dto.setOrderAmount(rs.getString("orderAmount"));
				dto.setPosNum(rs.getString("posNum"));
				inquiryReceipt.add(dto);
				
			}
			
			return inquiryReceipt;

		} catch (Exception e) {
			System.out.println("InquiryDAO.salesReceipt : " + e.toString());
		}
		
		return null;
		
	}//method: salesReceipt
	
	
}//Class: InquiryDAO





package com.twotwo.order;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/order/order2.do")
public class Order2 extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//Order2.java
		//1.데이터가져오기
		//2.DB작업 > DAO위임(insert)
		//3.결과반환 + JSP호출
		
		//1. 데이터가져오기
		String searchgo = req.getParameter("searchgo");
		//System.out.println(searchgo);

		req.setAttribute("searchgo", searchgo);
		//System.out.println(searchgo);
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/order/order2.jsp");
		dispatcher.forward(req, resp);

	}

}
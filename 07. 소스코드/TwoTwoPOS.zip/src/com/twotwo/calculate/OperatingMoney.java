package com.twotwo.calculate;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/calculate/operatingMoney.do")
public class OperatingMoney extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//{primary type name}
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/calculate/operatingMoney.jsp");
		dispatcher.forward(req, resp);
	}

}


package com.twotwo.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.twotwo.home.DBUtil;



public class EmployeeDAO {
	
	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public EmployeeDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}

	public VwEmployee  login(VwEmployee dto) {
		
			try {
			
			String sql = "select * from vwEmployee where userId = ? and userPw = ?";
			
			stat= conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId());
			stat.setString(2, dto.getUserPw());
			
			VwEmployee result = new VwEmployee();
			
			rs = stat.executeQuery();
			
			if(rs.next()) {
				//로그인 o
				result.setUserId(rs.getString("userId"));
				result.setUserPw(rs.getString("userPw"));
				result.setName(rs.getString("name"));
				result.setPosition(rs.getString("position"));
				result.setBlNumber(rs.getString("blNumber"));
				result.setBirthDate(rs.getString("birthDate"));
				result.setGender(rs.getString("gender"));
				result.setEmail(rs.getString("email"));
				result.setTel(rs.getString("tel"));
				result.setIbsadate(rs.getString("ibsadate"));
				result.setPwHintQ(rs.getString("pwHintQ"));
				result.setPwHintA(rs.getString("pwHintA"));
				result.setPic(rs.getString("pic"));
				result.setCafename(rs.getString("cafename"));
				
				return result;
			} else {
				//로그인 x
				return null;
			}
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.login : " + e.toString());
		}
		
		return null;
	}

	public int loginCheck(VwEmployee dto) {
		try {

			String sql = "select count(*) as cnt from vwEmployee where userId = ? and userPw = ?";
			
			stat= conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId());
			stat.setString(2, dto.getUserPw());
			
			rs = stat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("cnt");
			}
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.loginCheck : " + e.toString());
		}
		return 0;
	}
	
	public int idCheck(VwEmployee dto) {
		
		
		return 0;
	}

	public VwEmployee idSearch(VwEmployee dto) {

		try {

			String sql = "select userId, name from vwEmployee where name = ? and birthDate = ?";
			
			stat= conn.prepareStatement(sql);
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getBirthDate());
			
			rs = stat.executeQuery();
			
			VwEmployee result = new VwEmployee();
			
			if(rs.next()) {
				result.setUserId(rs.getString("userId"));
				result.setName(rs.getString("name"));
				return result;
			} else {
				
				return null;
			}
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.idSearch : " + e.toString());
		}
		return null;
	}

	public VwEmployee pwSearch(VwEmployee dto) {
		
		try {
			
			//System.out.println(dto.getUserId());
			
			String sql = "select userId, userPw, pwHintQ, pwHintA from vwEmployee where userId = ?";
			
			stat= conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId());
	
			rs = stat.executeQuery();
			
			VwEmployee result = new VwEmployee();
			
			if(rs.next()) {
				
				result.setUserId(rs.getString("userId"));
				result.setUserPw(rs.getString("userPw"));
				result.setPwHintQ(rs.getString("pwHintQ"));
				result.setPwHintA(rs.getString("pwHintA"));
				
				return result;
			} else {
				
				return null;
			}

		} catch (Exception e) {
			System.out.println("EmployeeDAO.pwSearch : " + e.toString());
		}
		return null;
	}

	public VwEmployee pwHintSearch(VwEmployee dto) {
		
		try {

			String sql = "select userId, userPw from vwEmployee where pwHintA = ?";
			
			stat= conn.prepareStatement(sql);
			stat.setString(1, dto.getPwHintA());
	
			rs = stat.executeQuery();
			
			VwEmployee result = new VwEmployee();
			
			if(rs.next()) {
				
				result.setUserId(rs.getString("userId"));
				result.setUserPw(rs.getString("userPw"));
		
				return result;
			} else {
				
				return null;
			}

		} catch (Exception e) {
			System.out.println("EmployeeDAO.pwSearch : " + e.toString());
		}
		return null;
	}

	public int idcheck(String id) {
		
		try {
			
			String sql = "select count(*) as cnt from vwEmployee where userId = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getInt("cnt");
			}
			
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.idcheck : " + e.toString());
		}
		return 0;
	}

	
	public int join(VwEmployee dto) {
		
		try {

			String sql = "insert into vwEmployee (employeeSeq, userId, userPw, name, position, blNumber, birthDate, gender, email, address, tel," + 
					"                                                                workTime, ibsadate, quitdate, pwHintQ, pwHintA, healthCertificate, educationComplete, pic, branchSeq)" + 
					"			                                                       values (employeeSeq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ' ', ?, 0, sysdate, ' ', ?, ?, 0, 0, ? , 1)";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId());
			stat.setString(2, dto.getUserPw());
			stat.setString(3, dto.getName());
			stat.setString(4, dto.getPosition());
			stat.setString(5, dto.getBlNumber());
			stat.setString(6, dto.getBirthDate());
			stat.setString(7, dto.getGender());
			stat.setString(8, dto.getEmail());
			stat.setString(9, dto.getTel());
			stat.setString(10, dto.getPwHintQ());
			stat.setString(11, dto.getPwHintA());
			stat.setString(12, dto.getPic());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("EmployeeDAO.join : " + e.toString());
		}
		
		return 0;
	}

	public void insertBranch(VwEmployee dto) {
		
		
try {
			
			String sql = "insert into tblBranch (branchSeq, name, lat, lng, tel, owner) values (branchSeq.nextval, 'TWOTWO', 0, 0, '02-745-2346', ?)";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getName());
			
			stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.insertBranch : " + e.toString());
		}
	}

	public int pwCheck(VwEmployee dto) {
		
		try {
			
			String sql = "select count(*) as cnt from vwEmployee where name = ? and userPw = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getUserPw());
	
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getInt("cnt");
			}
			
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.pwCheck : " + e.toString());
		}
		return 0;
	}

	public int delCheck(VwEmployee dto) {
		
		try {
			
			String sql = "select count(*) as cnt from vwEmployee where userId = ? and userPw = ? and blNumber = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId() );
			stat.setString(2, dto.getUserPw());
			stat.setString(3, dto.getBlNumber());
			
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getInt("cnt");
			}
			
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.delCheck : " + e.toString());
		}
		
		return 0;
	}

	public int delemployee(VwEmployee dto) {
		
		try {
			
			String sql = "update vwEmployee set userId ='0', userPw ='0' , name ='0', position ='0', blNumber ='0'" + 
					", birthDate ='0', gender ='0', email ='0', address ='0', tel ='0', workTime = 0, ibsadate ='0'" + 
					", quitdate ='0', pwHintQ ='0' , pwHintA ='0', healthCertificate =0, educationComplete =0," + 
					" pic = '0.png' where userId = ? and userPw = ? and blNumber = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getUserId());
			stat.setString(2, dto.getUserPw());
			stat.setString(3, dto.getBlNumber());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.delemployee : " + e.toString());
		}
		return 0;
	}

	public int pwChange(VwEmployee dto) {
		
		try {
			
			String sql = "update tblEmployee set userPw = ? where userId = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getUserPw());
			stat.setString(2, dto.getUserId());
		
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("EmployeeDAO.pwChange : " + e.toString());
		}
		
		return 0;
	}





	
	
}

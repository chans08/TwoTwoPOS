package com.twotwo.login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/idcheck.do")
public class Idcheck extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//Idcheck.java
		
		String jid = req.getParameter("jid");
		

		  if(jid != null) { //중복 검사 버튼 누름 
			
			  	EmployeeDAO dao = new EmployeeDAO(); 
			  	int result = dao.idcheck(jid); 
			  	req.setAttribute("result", result);
			  	req.setAttribute("jid", jid); 
			  	}
		 

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/login/idcheck.jsp");
		dispatcher.forward(req, resp);
	}
}

package com.twotwo.salesRegister;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/salesRegister/addsalelist.do")
public class AddSaleList extends HttpServlet {
	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		String categorySeq = req.getParameter("categorySeq");
		String menuSeq = req.getParameter("menuSeq");
		ArrayList<PaymentDTO> salelist = new  ArrayList<PaymentDTO>();
		
		if (session.getAttribute("salelist") == null) {
			session.setAttribute("salelist", salelist);
		} else {
			salelist = (ArrayList<PaymentDTO>) session.getAttribute("salelist");
		}
		
		ItemDTO dto = new ItemDTO();
		
		dto.setCategorySeq(categorySeq);
		dto.setMenuSeq(menuSeq);
		
		SalesRegisterDAO dao = new SalesRegisterDAO();
		ItemDTO iteminfodto = dao.getItemInfo(dto);
		
		boolean exist = false;
		for (PaymentDTO pdto : salelist) {
			if (pdto.getItemSeq().equals(iteminfodto.getItemSeq())) {
				exist = true;
				pdto.setOrderAmount(pdto.getOrderAmount() + 1);
				break;
			}
		}
		
		if (!exist && iteminfodto.getItemSeq() != null) {
			PaymentDTO saleitemdto = new PaymentDTO();
			saleitemdto.setItemSeq(iteminfodto.getItemSeq());
			saleitemdto.setItemName(iteminfodto.getItemName());
			saleitemdto.setOrderAmount(1);
			saleitemdto.setItemPrice(iteminfodto.getItemPrice());
			
			salelist.add(saleitemdto);
		}
		
		session.setAttribute("salelist", salelist);

		/*
		 * RequestDispatcher dispatcher =
		 * req.getRequestDispatcher("/WEB-INF/views/salesRegister/addsalelistdata.jsp");
		 * dispatcher.forward(req, resp);
		 */
	}
}

package com.twotwo.salesRegister;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.twotwo.home.DBUtil;

public class GenerateInsertItemFirstPage {
	
	public static void main(String[] args) {
		
		try {
			
			DBUtil util = new DBUtil();
			Connection conn = util.connect();
			PreparedStatement stat;
			
			for (int j=1; j<=34; j++) {
				
				int i = 1;
				
				String sql = "insert into tblitem (itemSeq, menuSeq, itemName, itemPrice, categorySeq) "
								+ "values (itemseq.nextval, " + j + ", ?, null, " + i + ")";
				
				stat = conn.prepareStatement(sql);
				stat.setString(1, String.format("%d-%d번째 메뉴", i, j));
				stat.executeUpdate();
				
				System.out.println(j + " inserted.");
				
			}
			
		} catch (Exception e) {
			System.out.println("GenerateInsertItemFirstPage.java.main : " + e.toString());
		}
		
	}
	
}
